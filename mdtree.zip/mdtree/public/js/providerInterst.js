mdtreeApp.controller('providerInterst', function providerInterst($scope,$state,productService,$http,$timeout,SelectValueService){
    $scope.oneAtATime = true;

     $http.get('v1/listInteresetd').success(function(data){  
                console.log(data);
                $scope.interestProviders = data.interestProvider;

            }).error(function(data, status, headers, config) {
              console.log(data);
        }); 
      $scope.status = {
        isFirstOpen: true,
        isFirstDisabled: false
      };
});
