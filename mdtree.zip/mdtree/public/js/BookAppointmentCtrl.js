
mdtreeApp.controller('BookAppointmentCtrl',function BookAppointmentCtrl($stateParams,$scope,$timeout,productService,$state,$http,Auth,SelectValueService){
   
    
    $scope.userid = Auth.user;
    console.log($stateParams);
    $state.stateParams = $stateParams;
    // $scope.specialty.doctor = productService.getspecialty();
    // $scope.insurance = productService.getinsurance();
    // $scope.categories = productService.getcategory();
    $scope.emailid = $stateParams.email;
    // $scope.getinsuranceValue = productService.getaddinsurance();
    // http://localhost:8000/v1/provider/search?zip=90002&specialty=cardiology&category=doctors&insurance=aarp&email=thanesh@gmail.com

    
    // if ($scope.insurance) {
    //     queryParams += "&insurance="+encodeURIComponent($scope.insurance);
    // }

    // console.log(queryParams);
    
    $scope.reasons = {};
    $scope.reasons.options = [{reason:"Special offer"},{reason:"Abdominal pain"},{reason:"Abnormal bleeding"},{reason:"Allergies"},{reason:"Anxiety"},{reason:"Burning w or urination"},{reason:"Chest pain"},{reason:"Constipation"},{reason:"Coughing"},{reason:"Cracked tooth"},{reason:"Crying"},{reason:"Dental pain"},{reason:"Depression"},{reason:"Diarrhea"},{reason:"Difficulty breath"},{reason:"Discoloration"},{reason:"Dizziness"},{reason:"Dryness"},{reason:"Erectile Dysfunction"},{reason:"Excessive thirst"},{reason:"Fibroids"},{reason:"Frequent bruising"},{reason:"Frequent urination"},{reason:"Genital discharge"},{reason:"Genital odor"},{reason:"Gum pain"},{reason:"Hair loss"},{reason:"Hay Fever"},{reason:"Heart burn"},{reason:"Heat or cold intolerance"},{reason:"Hives"},{reason:"I need braces"},{reason:"Incontinence"},{reason:"Infertility"},{reason:"Joint pain"},{reason:"Loss of hearing"},{reason:"Low libido"},{reason:"Lumps"},{reason:"Mole Changes"},{reason:"Muscle pain"},{reason:"Muscle weakness"},{reason:"Nausea"},{reason:"Nipple discharge"},{reason:"Numbness or tingling"},{reason:"Oily"},{reason:"Painful intercourse"},{reason:"Painful menstruation"},{reason:"Palpitations"},{reason:"Phlegm"},{reason:"Poor circulation"},{reason:"Postcoital bleeding"},{reason:"Rash"},{reason:"Regurgitation"},{reason:"STD"},{reason:"Seizures"},{reason:"Shortness of breath"},{reason:"Sinus problems"},{reason:"Skin changes"},{reason:"Sleep apnea"},{reason:"Sore throat"},{reason:"Swelling"},{reason:"Swollen glands"},{reason:"Teeth cleaning"},{reason:"Teeth whitening"},{reason:"Thoughts of suicide"},{reason:"Tinnitus or Ringing in ears"},{reason:"Urine retention"},{reason:"Vomiting"},{reason:"Wheezing"},{reason:"Wounds"}]

    $scope.bookingdate = [];
    var dayShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var date = new Date();
    $scope.getYearandDate = new Date(date);
    console.log(date.getDay());
    var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    $scope.indexValue = 0;
    $scope.nextslots = function(value){
           // console.log($scope.bookingdate); 
           
           var date = new Date($scope.getYearandDate);
           $scope.bookingdate = [] ;
           if (value == 'prev'){
                
                date.setDate(date.getDate() - 5);
                $scope.indexValue = $scope.indexValue - 1; 
                $scope.getYearandDate = new Date(date);

           }
           else{
                // $scope.getYearandDate = date;
                date.setDate(date.getDate() + 5);
                $scope.indexValue = $scope.indexValue + 1; 
                $scope.getYearandDate = new Date(date);
                
           }
            
            var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            $scope.firstsearchoperation($scope.indexValue);
            //localhost:8000/v1/provider/search?zip=90002&specialty=cardiology&category=doctors&insurance=AArp&startindex=1
        }
    
    $scope.firstsearchoperation = function(indexValue) {
        var queryParams = "v1/provider/search?";
        if ($stateParams.category) {
            queryParams += "category="+$stateParams.category
        } else {
            queryParams + "category=doctors";
        }
        if ($stateParams.doctor) {
            queryParams += "&specialty="+$stateParams.doctor;
        }
        if ($stateParams.location) {
            queryParams += "&zip="+$stateParams.location;
        }
        if ($stateParams.email) {
            queryParams += "&email="+$stateParams.email;
        }
        
        // if ($scope.insurance) {
        //     queryParams += "&insurance="+encodeURIComponent($scope.insurance);
        // }

        console.log(queryParams);
            

        if(indexValue != undefined){
            queryParams = queryParams + "&startindex=" + indexValue;
        }
        console.log(queryParams);
        $scope.myPromise = $http.get(queryParams);
        $scope.myPromise
            .success(function(data, status, headers, config) {
                console.log(data);
                if(indexValue != undefined){
                    $scope.singledoctor.appointmentSchedules = data.provider.appointmentSchedules;
                }else{
                    $scope.singledoctor = data.provider;
                }
                
                $scope.appointmentHideOrShow="true"
                var tempValue =  _.findWhere(SelectValueService.getOfferJson(), {key:data.provider.offerStmt}) ;
                 if(tempValue){
                        $scope.singledoctor.offerStmt = tempValue.id;
                    } 
                for(var j=0;j<data.provider.appointmentSchedules.length;j++){
                    
                    for(var k=0;k<data.provider.appointmentSchedules[j].slots.length;k++){
                            console.log("appointmentHideOrShow");
                            $scope.appointmentHideOrShow="false";
                    }
                }
                    
            })
            .error(function(data, status, headers, config) {
                console.log(data);
        });
    }
    $scope.firstsearchoperation();


    $scope.timeclicked = function(doctor, md_date, md_time,title,desc,offerStmt) {

            var dayFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            $scope.user=Auth.user;
            var date = new Date(md_date);
            var datadetails = {date : md_date, day: dayFull[date.getDay()], time: md_time,offer:title,desc:desc,offerStmt:offerStmt};
            if($scope.user.type === 'patient'){
                var tempurl = '/v1/slotStatus?location='+doctor.locationId+'&email='+doctor.email+'&date='+md_date+'&slot='+md_time;
                $http.get(tempurl)
                    .success(function(data, status, headers, config) {
                       console.log(data);
                        $state.go("public.appDetails2",({doctor:JSON.stringify(doctor),data:JSON.stringify(datadetails),searchData:JSON.stringify($stateParams)}))
            
                    })
                    .error(function(data, status, headers, config) {
                        console.log(data);
                        productService.adderrormsgwhenAppointment(data.message);
                        $scope.ErrorChecking();
                });
            }else{
                if($scope.user.role.title === 'public'){
                    var tempjsonForSlotStatus = {locid:doctor.locationId,doc:doctor.email,date:md_date,slotTime:md_time};
                    productService.addSlotStatus(tempjsonForSlotStatus);
                    
                }
                $state.go("public.appDetails2",({doctor:JSON.stringify(doctor),data:JSON.stringify(datadetails),searchData:JSON.stringify($stateParams)}))
            
                
            }  
    }

    
    // productService.addlocationdetails();
});





