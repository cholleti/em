mdtreeApp.controller('patientdashboardcontroller', function providerController($scope,Auth,$state,productService,SelectValueService,$http,$timeout,$upload,fileReader,$location,$modal){

	$scope.user = Auth.user;
	$scope.gotoproviderdetails = function(email,zipcode){
		$scope.stateParams = {location:zipcode}
		
		$state.go('public.doctorDetails',({email:email,searchData:JSON.stringify($scope.stateParams)}));
	}
	$scope.typeVisit = {};
    $scope.typeVisit.options = [{type:"Phone",id:"Phone Consultation"},{type:"Video",id:"Online Exam Room"}];
    
	$scope.form = {};
	$scope.categories = {};
    $scope.insurance = {};
    $scope.insurance.type = 'insure_1';
    $scope.specialty= {};
    $scope.categories.options = SelectValueService.getCategoryJson();
    $scope.specialty.options = SelectValueService.getDoctorsJson();
    $scope.insurance.options = SelectValueService.getinsuranceJson();
    $scope.dentistslists= {};
    $scope.dentistslists.options = SelectValueService.getdentistslists();
    $scope.otherSpeciality = {};
    $scope.otherSpeciality.options = SelectValueService.getotherSpeciality();
    $scope.chiropractors= {};
    $scope.chiropractors.options = SelectValueService.getchiropractors();
    $scope.gender= {};
    $scope.gender.options = [{gender:"male"},{gender:"female"}];
    $scope.language= {};
    $scope.language.options = SelectValueService.getLangJson();
    $scope.calenderDateFormat = function(currentDate){
        var formatDate = "";
        if (currentDate.getMonth()<9) {
            formatDate += "0" + (currentDate.getMonth()+1);
          } else {
            formatDate += (currentDate.getMonth()+1);
          } 
          if (currentDate.getDate() < 10) {
            formatDate += "-" + "0" + currentDate.getDate();
          } else {
            formatDate += ("-" + currentDate.getDate());
          }
          
          formatDate += "-" + currentDate.getFullYear();

          // console.log(formatDate);
          return formatDate;
    } 
    $scope.formatAMPM = function (date) {
          var hours = date.getHours();
          var minutes = date.getMinutes();
          var ampm = hours >= 12 ? 'PM' : 'AM';
          hours = hours % 12;
          hours = hours ? hours : 12; // the hour '0' should be '12'
          minutes = minutes < 10 ? '0'+minutes : minutes;
          var strTime = hours + ':' + minutes + ampm;
          return strTime;
    }
    $scope.toMinutes = function (time){
        var hr = time.substring(0,time.indexOf(":"));
        var min = time.substring(time.indexOf(":")+1,time.length-2);
        var ampm = time.search("AM");
        var totalmin=0;
        if(ampm>0){ 
            if(hr==12)hr=0;
            return (hr*60)+parseInt(min);
        }
        else{
            if(hr==12)hr=0;
            return (hr*60)+parseInt(min)+720;
        }
    }
    $scope.open = function (index) {
      $scope.item=index;
        $scope.modalInstance = $modal.open({
          templateUrl: 'myModalContent.html',
          controller: 'ModalInstanceCtrl',
          backdrop: 'static',
          resolve: {
            items: function () {
              return $scope.item;
            }
          }
        });
        $scope.modalInstance.result.then(function() {
        }, function(items) {
        	$scope.pendingappointment[items].payment = true;
         
        })['finally'](function(){
          $scope.modalInstance = undefined  // <--- This fixes
        });
      };
      $scope.cancel = function () {
	    $modalInstance.dismiss('cancel');
	      console.log("close");
	  };
    $scope.getpastVisit = function  () {
    	$http.get('/v1/appointmentHistory?email='+$scope.user.email)
	        .success(function(data, status, headers, config) {
	            console.log(data);
	            $scope.pastappointment = data.pastappointment;
                angular.forEach(data.pastappointment, function(pastappointment, index){
		                if(pastappointment.type){
		                	console.log(pastappointment.type);
		                	$scope.pastappointment[index].location =  _.findWhere($scope.typeVisit.options, {type:pastappointment.type});
		                	$scope.pastappointment[index].appointmentStates = "Appointment Completed";
		                }
		                $scope.pendingappointment.push(pastappointment);
		         });
	        })
	        .error(function(data, status, headers, config) {
	            console.log(data);
		});
    }
	$scope.breakMintus = 15;
	$scope.notifications = false;
	$scope.getPendingAppointment = function  (date) {
		
	
		$http.get('/v1/appointmentHistory?email='+$scope.user.email+'&date='+date)
		        .success(function(data, status, headers, config) {
		            console.log(data);
		            $scope.pendingappointment = data.appointments;
			        if(date < $scope.calenderDateFormat(new Date())){
		        		angular.forEach(data.pendingappointment, function(pendingappointment, index){
			                if(pendingappointment.type){
			                	$scope.pendingappointment[index].location =  _.findWhere($scope.typeVisit.options, {type:pendingappointment.type});
			                	$scope.pendingappointment[index].appointmentStates = "Appointment Completed";
			                }
			                
				         });
			        }
			        else{
			        	angular.forEach($scope.pendingappointment, function(pendingappointment, index){
			                if(pendingappointment.type){
			                	console.log(pendingappointment.type);
			                	$scope.pendingappointment[index].location =  _.findWhere($scope.typeVisit.options, {type:pendingappointment.type});
			                	if(pendingappointment.date === $scope.calenderDateFormat(new Date())){
			                		var time = $scope.toMinutes($scope.formatAMPM(new Date()));
									// var time = $scope.toMinutes("11:40AM");
						    		var booktime = $scope.toMinutes(pendingappointment.time);
						    		// var booktime = $scope.toMinutes("11:55AM");
						    		
						    		var diffTime = booktime - time;
						    		console.log(time,booktime,diffTime);
						    		if(diffTime <= 15 && diffTime >= -10){
						    			$scope.pendingappointment[index].timeWithinMintues = true;
						    			$scope.notifications = true;
						    		}
			                	}
			                }
			         	});
			        }
		            
		            
		            // $scope.getpastVisit();
	                
		        })
		        .error(function(data, status, headers, config) {
		            console.log(data);
		});
	}
	$http.get('/v1/patient?email='+$scope.user.email)
	        .success(function(data, status, headers, config) {
	            console.log(data);
	            $scope.patient = data.patient;
                if(data.patient.gender === 'female'){
                	$scope.boolChangeClass = true;
                }else{
                	$scope.boolChangeClass = false;
                }
	        })
	        .error(function(data, status, headers, config) {
	            console.log(data);
	});
	$scope.searchoperation = function(zipcode){
		 if(zipcode.Zipcode){
                zipcode = zipcode.Zipcode;
            }
        $state.go("public.search",({doctor:$scope.specialty.doctor,location:zipcode,
        	insurance:$scope.insurance.type,category:$scope.categories.type}))
       
	}
	$scope.cityWithStateNames = _.shuffle(SelectValueService.getstateCityZipcode());
	$scope.formclick = false;
    $scope.valuefunction = function(){
    	 $scope.formclick = false;
        $scope.password = "";
        $scope.oldpassword = "";
         $scope.repassword = "";
    }
	$scope.passwordchangefn = function(old,newpas){
		var passwordJson = {"password":old,"newpassword":newpas};
		console.log(passwordJson);
		$http.put('/v1/changePassword?email='+$scope.user.email,passwordJson)
	        .success(function(data, status, headers, config) {
	            console.log(data);
	            $scope.valuefunction(data);
	             var msg = data;
                var type = "success";
                $timeout(function(){
                	$scope.form={};
                	$scope.passwordalerts =[];

                	$scope.changepasswordview = {};
                    $scope.changepasswordview.view = false;
             	}, 5000);
                $scope.passwordalerts =[];
                $scope.passwordalerts.push({msg: msg,type: type});
	        })
	        .error(function(data, status, headers, config) {
	        	$scope.form={};
	        	$scope.formclick = true;
	            console.log(data);
	             var msg = data.message;
                var type = "danger";
                $timeout(function(){
                    $scope.passwordalerts =[];
             	}, 5000);
                $scope.passwordalerts =[];
                $scope.passwordalerts.push({msg: msg,type: type});
			});

	}
	$scope.changepasswordview = {};
	$scope.changesecurity = {};
	$scope.changesecurity.view = false;
	$scope.changepasswordview.view = false;
	$scope.ChangeSecurityQus = function(securityanswer){
		$http.put('/v1/changeSecurity?email='+$scope.user.email,{"question":$scope.questions.select,"answer":securityanswer})
	        .success(function(data, status, headers, config) {
	            console.log(data);
	            var msg = data;
                var type = "success";
                $timeout(function(){
                    $scope.Securityalerts =[];
                    $scope.changesecurity = {};
             	}, 5000);
                $scope.Securityalerts =[];
                $scope.Securityalerts.push({msg: msg,type: type});
	           	
	        })
	        .error(function(data, status, headers, config) {
	            console.log(data);
	             var msg = data.message;
                var type = "danger";
                $timeout(function(){
                    $scope.Securityalerts =[];

             	}, 5000);
                $scope.Securityalerts =[];
                $scope.Securityalerts.push({msg: msg,type: type});
		});
	}
	$scope.questions = {};
	$scope.questions.options = SelectValueService.getQusTypeJson();
	$scope.displayTermMessage = function(){
      $scope.DisplayTermMessageError ="You must read and accept the Terms & Conditions before submitting the details. "
    }
  //   $scope.getChangeSecurityQus = function(){
  //   	$http.get('/v1/getSecurity?email='+$scope.user.email)
	 //        .success(function(data, status, headers, config) {
	 //            console.log(data);
	 //           	$scope.questions.select = data.security.question;
	 //           	$scope.Securityanswer = data.security.answer;
	 //        })
	 //        .error(function(data, status, headers, config) {
	 //            console.log(data);
		// });
  //   }
    
    $scope.pressedCancel = function () {
    	$scope.changepasswordview.view = false;
    	 $scope.form = {};
    	 
    }
    
    $scope.phoneerrormessage = "Invalid phone number format";
    $scope.date = {};
    $scope.date.currentDate = $scope.calenderDateFormat(new Date());
   	$scope.$watch('date.currentDate',function(){
   		console.log($scope.date.currentDate);
        $scope.getPendingAppointment($scope.date.currentDate);
    });


	$scope.paitentUpdateProfile = function(boolChangeClass){
		$scope.showPhoneerror = false;
		// console.log($scope.patient.phone.length);
		// console.log(!($scope.patient.phone.length === "10" || $scope.patient.phone.length === "11"))
		if(!($scope.patient.phone.length== 10 || $scope.patient.phone.length == 11)){

			$scope.showPhoneerror = true;
		}else{
			console.log(boolChangeClass);
				if(boolChangeClass){
		              var gender = "female";
		          }else{ var gender = "male" };
		          console.log(gender);
				var Patientjson = {"firstName":$scope.patient.username,"lastName":$scope.patient.lastName,
				"phone":$scope.patient.phone,"zipCode":$scope.patient.zipCode,"gender":gender,"dob":$scope.patient.dob}
				console.log(Patientjson);
				$http.put('/v1/updatePatient?email='+$scope.user.email,Patientjson)

			        .success(function(data, status, headers, config) {
			            console.log(data);
			             var msg = data;
		                var type = "success";
		                $timeout(function(){
		                    $scope.alerts.splice(0, 1);
		             	}, 5000);
		                $scope.alerts =[];
		                $scope.alerts.push({msg: msg,type: type});
			        })
			        .error(function(data, status, headers, config) {
			            console.log(data);
			             var msg = data.message;
		                var type = "danger";
		                $timeout(function(){
		                    $scope.alerts.splice(0, 1);
		             	}, 5000);
		                $scope.alerts =[];
		                $scope.alerts.push({msg: msg,type: type});
			});
		}
		
	}

});
mdtreeApp.controller('ModalInstanceCtrl',['$scope', '$timeout', '$http', '$state', '$upload', 'Auth', '$modalInstance', 'items',
 function ModalInstanceCtrl($scope, $timeout, $http, $state, $upload, Auth, $modalInstance, items) {
 	$scope.doSomething=function(){
	    //any actions to take place
	    console.log("Do Something");
	     $modalInstance.dismiss(items);
	    

	}

}]);