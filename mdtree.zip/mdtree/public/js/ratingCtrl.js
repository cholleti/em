mdtreeApp
.controller('ratingCtrl', ['$rootScope', '$scope', '$location', 'Auth','$state','productService','$timeout','$stateParams','$http',
    function($rootScope, $scope, $location, Auth,$state,productService,$timeout,$stateParams,$http) {
    	$scope.questions = ["1) Physician's bedside manner",
				"2) The physician's apparent level of knowledge regarding my symptoms and chief complaint",
				"3) Office accessibility",
				"4) Friendliness of the staff",
				"5) Punctuality of physician and staff",
				"6) Office cleanliness",
				"7) Efficiency of office staff",
				"8) Physician's communication skills",
				"9) My questions were answered",
				"10) I would recommend this Physician"];
		$scope.resultValue = [];
		$scope.submitRating = function  () {
			var url = 'v1/addRating?appointmentId='+ $stateParams.appointmentId;
			var reviewData = {answer:$scope.resultValue,message:$scope.reviewText};
			console.log(url,reviewData);
			 $http.post(url,reviewData).success(function(data){  
                console.log(data);
                $state.go('user.RatingSuccessFull',{error:true});
            }).error(function(data, status, headers, config) {
            	$state.go('user.RatingSuccessFull',{error:false,errorMessage:"eroorMessage"});
        	}); 
		}
    }]);