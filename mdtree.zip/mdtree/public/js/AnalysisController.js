mdtreeApp.controller('AnalysisController',function AnalysisController($scope,$timeout,productService,$state,$http,Auth){
$scope.options = 0;
  $scope.width = 500;
    $scope.height = 500;
    $scope.changeView = function(value){
      $scope.selectedOption = value;
      $scope.appointment = null;
      $scope.exampleData = [];
      $scope.piechart = [];
       $scope.formData = {};
    }
    $scope.dateChange = function(formData){
      console.log(formData);
      if(formData.form && formData.to ){
        if($scope.options === 'zip'){
          var url = '/v1/hitAnalysis?fromDate='+formData.form+'&toDate='+formData.to;
        }else if($scope.options === 'plan'){
          var url = '/v1/hitAnalysisType?fromDate='+formData.form+'&toDate='+formData.to;
        }else{
          var url = '/v1/providerAnalysis?fromDate='+formData.form+'&toDate='+formData.to;
        }
        // var url ='/v1/onBoard?fromDate='+formData.form+'&toDate='+formData.to;
        $scope.getDataFromServer(url);
        
      }
      
    }
    $scope.monthChange = function(month){
      month=  Number(month) +1 ;
      console.log(month);
      if($scope.options === 'zip'){
        var url = '/v1/hitAnalysis?year='+new Date().getFullYear()+'&month='+month;
      }else if($scope.options === 'plan'){
          var url = '/v1/hitAnalysisType?year='+new Date().getFullYear()+'&month='+month;
        }else{
        var url = '/v1/providerAnalysis?year='+new Date().getFullYear()+'&month='+month;
      }

      // var url ='/v1/onBoard?year='+new Date().getFullYear()+'&month='+month;
      $scope.getDataFromServer(url);
    }
    $scope.yearChange = function(year){
      console.log(year);
      if($scope.options === 'zip'){
        var url = '/v1/hitAnalysis?year='+year
      }else if($scope.options === 'plan'){
          var url = '/v1/hitAnalysisType?year='+year
        }else{
        var url = '/v1/providerAnalysis?year='+year
      }
      // var url ='/v1/onBoard?year='+year;
      $scope.getDataFromServer(url);
    }
    $scope.monthyearChange = function(year,month){
      month= Number(month) +1;
      if($scope.options === 'zip'){
        var url = '/v1/hitAnalysis?year='+year+'&month='+month
      }else if($scope.options === 'plan'){
          var url = '/v1/hitAnalysisType?year='+year+'&month='+month
        }else{
        var url = '/v1/providerAnalysis?year='+year+'&month='+month
      }
      // var url ='/v1/onBoard?year='+year+'&month='+month;
      $scope.getDataFromServer(url);
    }
    $scope.changeView('date');
    $scope.xFunction = function() {

      return function(d) {
     
        // console.log(d);
        return d.key;
      };
    }
    $scope.yFunction = function() {
      return function(d) {
         // console.log(d,"y");
        return d.total;
      };
    }
        $scope.getDataFromServer = function(url) {
          $scope.exampleData = [];
          $scope.promises = $http.get(url)
          $scope.promises.success(function(data){  
                console.log(data);
                  $scope.piechart =  [{
                    "key":"mdtree",
                    "values":data.hitAnalysis

                      }

                   ];
                   $scope.exampleData = data.hitAnalysis[0][2].providers;
                    console.log($scope.piechart);
                  // }]];
                

            }).error(function(data, status, headers, config) {
              $scope.serverError = data.message;
          })
        }
        $scope.hitAnalysisData = function(){
          console.log($scope.options);
          if($scope.options === 'zip'){
            var url = '/v1/hitAnalysis'
          }else if($scope.options === 'plan'){
            var url = '/v1/hitAnalysisType'
          }
          else{
            var url = '/v1/providerAnalysis'
          }
          $scope.getDataFromServer(url);
        }
        $scope.hitAnalysisData('zip');
        $scope.options = 'zip';
        


             var flag ;

      $scope.$on('elementClick.directive', function(angularEvent, event){
        console.log(event);
        // $scope.otherFunction(event,$scope.exampleData)
            $scope.$apply(function(){
                $scope.exampleData = event.point[2].providers;
                console.log($scope.exampleData);
            });
      });
      var colorArray1 = ['#e11858'];
        $scope.colorFunction1 = function() {
          return function(d, i) {
            console.log(d);
              return colorArray1[i];
          };
        }
       var colorArray2 = ['#009da2']; 
       $scope.colorFunction2 = function() {
          return function(d, i) {
            console.log(d);
              return colorArray2[i];
          };
        }
        $scope.changeFunction = function(options){
          

          // $scope.piechart = JSON.parse(JSON.stringify($scope.piechartss[$scope.options]));
          // alert("hai")
          // console.log( $scope.piechart[0].values[0][2].Providers);
          // $scope.exampleData = JSON.parse(JSON.stringify($scope.piechart[0].values[0][2].Providers));
        }

});