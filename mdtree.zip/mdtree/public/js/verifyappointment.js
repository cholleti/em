
mdtreeApp.controller('verifyappointment',function verifyappointment($stateParams,$scope,$timeout,productService,$state,$http,Auth,SelectValueService){
   
    $scope.userid = Auth.user;
    console.log($stateParams);


    $scope.NumberConfrm = true;
    $scope.doctordetails = JSON.parse($stateParams.doctor);
    $scope.daytimedetails = JSON.parse($stateParams.data);
    $scope.searchData = JSON.parse($stateParams.searchData);
    console.log($scope.searchData);
    $scope.typeVisit = {};
    $scope.typeVisit.options = [{type:"Phone",id:"Phone Consultation"},{type:"Video",id:"Online Exam Room"}];
    $scope.insurance = {};
    $scope.insurance.options = SelectValueService.getinsuranceJson()
    if(!$scope.searchData){
       $scope.searchData = {}
        $scope.searchData.insurance = 'insure_1';

    }else if(!$scope.searchData.insurance){
      $scope.searchData.insurance = 'insure_1'
    }

    var Selectedinsurance =  _.findWhere($scope.insurance.options, {key:$scope.searchData.insurance});
    if(Selectedinsurance){
      $scope.getinsuranceValue = Selectedinsurance.value;
    }

    
    $scope.reason = JSON.parse($stateParams.personaldetails);
    if($scope.reason.type){
      $scope.selectedType =  _.findWhere($scope.typeVisit.options, {id:$scope.reason.type});
    }
     

    console.log($scope.doctordetails);
    // $scope.locationDetails = productService.getlocationdetails();
    $scope.getlocationForMap = {address : $scope.doctordetails.address + "," + $scope.doctordetails.city  + "," + $scope.doctordetails.state + "," + $scope.doctordetails.zip,zip: $scope.doctordetails.zip};
    console.log($scope.getlocationForMap);

     $scope.getUserinfo = function(){
        var url = '/v1/patient?email='+$scope.userid.email;
        $http.get(url).success(function(data){  
            console.log(data);
            $scope.daytimedetails.user = data;

        })
        .error(function(data, status, headers, config) {

        });
     }   
     $scope.getUserinfo();


    $scope.initialize = function (value) {

        if(value){
            $scope.MapViewOption = true;
        }
        
        if(document.getElementById("map_canvas") == null) return;
      if (GBrowserIsCompatible()) {
        var map = new GMap2(document.getElementById("map_canvas"));
        //map.setCenter(new GLatLng(37.4419, -122.1419), 13);
        map.setUIToDefault();
      }      

      geocoder = new GClientGeocoder();
      console.log(geocoder.getLatLng);
      // var address = 'madurai';
      console.log($scope.getlocationForMap);
      address = $scope.getlocationForMap.zip;
      addMarkers(map, address, 0);
      // $scope.findmaplocation = ["pasumalai","villapuam","nilaiyur"];
      console.log($scope.findmaplocation);
      // for ( var i=0;i<$scope.findmaplocation.length;i++){
        address = $scope.getlocationForMap.address;
           // address = $scope.findmaplocation[i].address + "," + $scope.findmaplocation[i].city + ","+ $scope.findmaplocation[i].state;
          infoText = "<html><div align=\"left\">" + address + "</div></html>";
            addMarkers(map,address, 1, 1, infoText);
            console.log(address);
        // }
      
      
    }
    

    $scope.displayErrorMsg = function  () {
            $scope.errorMsgForPhone = "Confirm Your Phone Number"
    }
    $scope.NumberConfrm = true;
     $scope.phoneNumberNotConfrm = function  () {
        $scope.errorMsgForPhone = ""
         $scope.NumberConfrm = false;
         $scope.PhoneEdit = true;
     }
    $scope.phoneNumberConfrm = function  () {
        $scope.errorMsgForPhone = "";
        $scope.NumberConfrm = false;
        $scope.PhoneEdit = false;
    }
    $scope.displayErrorMsg = function  () {
            $scope.errorMsgForPhone = "Confirm Your Phone Number"
    }
    $scope.CancelupdateUserPhone = function(){
        $scope.NumberConfrm = true;
        $scope.PhoneEdit = false;
    }
    $scope.initialize();
    
    function addMarkers(map, address, val, iconNo, infoText) {
        
        if (geocoder) {
          geocoder.getLatLng(
            address,
            function(point) {
              if (!point) {
              //alert(address + " not found");
              } else {
                if(val == 0) {
                    map.setCenter(point, 11);
                } else {
                    var url = "images/GoogleMap/free/pin" + (iconNo) + ".png";
                    gicons = new GIcon(G_DEFAULT_ICON, url); 
                    console.log(gicons);

                    var marker = new GMarker(point, gicons);
                    /* marker.openInfoWindowHtml("Some other stuff"); */
                    map.addOverlay(marker);
                    GEvent.addDomListener(document.getElementById('pin' + iconNo), "click", function() { 
                        marker.openInfoWindowHtml(infoText); 
                    });
                    GEvent.addDomListener(marker, "click", function() { 
                        marker.openInfoWindowHtml(infoText); 
                    });
                }
              }
            }
          );
        }
    }

       $scope.phoneNumberNotConfrm = function  () {
        $scope.errorMsgForPhone = ""
         $scope.NumberConfrm = false;
         $scope.PhoneEdit = true;
     }
    $scope.phoneNumberConfrm = function  () {
        $scope.errorMsgForPhone = "";
        $scope.NumberConfrm = false;
        $scope.PhoneEdit = false;
    }
     $scope.CancelupdateUserPhone = function(){
        $scope.NumberConfrm = true;
        $scope.PhoneEdit = false;
    }
    $scope.phoneerrormessage = "Invalid phone number format";
    $scope.updateUserPhone = function  () {
      $scope.showPhoneerror = false;
      if( !($scope.daytimedetails.user.patient.phone.length== 10 || $scope.daytimedetails.user.patient.phone.length == 11)){

      $scope.showPhoneerror = true;
    }else{

        console.log($scope.daytimedetails.user.patient.firstName);
       var Patientjson = {"firstName":$scope.daytimedetails.user.patient.username,"lastName":$scope.daytimedetails.user.patient.lastName,
       "phone":$scope.daytimedetails.user.patient.phone,"zipCode":$scope.daytimedetails.user.patient.zipCode,
       "gender":$scope.daytimedetails.user.patient.gender,"dob":$scope.daytimedetails.user.patient.dob}
        
        $http.put('/v1/updatePatient?email='+$scope.userid.email,Patientjson)

            .success(function(data, status, headers, config) {
                console.log(data);
                $scope.PhoneEdit = false;
                $scope.NumberConfrm = true;
                 var msg = data;
                var type = "success";
                $timeout(function(){
                    $scope.alerts.splice(0, 1);
                }, 5000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
            })
            .error(function(data, status, headers, config) {
                console.log(data);
                 var msg = data.message;
                var type = "danger";
                $timeout(function(){
                    $scope.alerts.splice(0, 1);
                }, 5000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
        });
      }
    }
    $scope.bookAppoinmentcomplete = function(){
        var url = '/v1/patient?email='+$scope.userid.email+'&view=info';
        $scope.disableBookAppiontmentButton = true;
        $http.get(url).success(function(data){  
            console.log(data);
            $scope.daytimedetails.user = data;

        
        

        var bookAppoinmentjson;
                if (true){ 
                    bookAppoinmentjson = {
                        location:$scope.doctordetails.locationId,
                        provideremail:$scope.doctordetails.email,
                        date:$scope.daytimedetails.date,
                         email:$scope.userid.email,
                         name:$scope.userid.username,
                         insurance:$scope.searchData.insurance,
                         message:$scope.reason.personalmsg,
                        slot:$scope.daytimedetails.time,
                        phoneno:data.patient.phone,
                        gender:data.patient.gender
                    }
                   
                    
                }
                console.log($scope.reason.type);
              if($scope.reason.type){
                      bookAppoinmentjson.type = $scope.selectedType.type;
                }else{
                      bookAppoinmentjson.purpose = $scope.reason.visitreason;
                }
             console.log(bookAppoinmentjson);
            $http.put('v1/appointment', bookAppoinmentjson).success(function(data){  
                        console.log(data);
                        productService.addErrorAppointment();
                        $scope.appiointmentDetails = data.appointment;
                         $state.go('user.appointment-complete',({details:JSON.stringify($scope.appiointmentDetails),type:$scope.selectedType.type}))
                        $scope.disableBookAppiontmentButton = false;
                

                    }).error(function(data, status, headers, config) {
                        productService.addErrorAppointment(data.message);
                        console.log(data);
                        $scope.disableBookAppiontmentButton = false;
                        var msg = data.message;
                        var type = "danger";
                        $timeout(function(){
                            $scope.alerts.splice(0, 1);
                        }, 5000);
                        $scope.alerts =[];
                        $scope.alerts.push({msg: msg,type: type});
                        // var searchData = $stateParams.searchData;
                        // console.log(searchData);
                        $state.go('user.appointment-complete',({searchData:JSON.stringify($scope.searchData)}))
                         
                }); 

       })
    }
});
