mdtreeApp
.controller('ratingCompleteCtrl', ['$rootScope', '$scope', '$location', 'Auth','$state','productService','$timeout','$stateParams',
    function($rootScope, $scope, $location, Auth,$state,productService,$timeout,$stateParams) {
    	console.log($stateParams);
    	$scope.stateParams = $stateParams;
    }]);