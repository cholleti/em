mdtreeApp.controller('appointmentdetails', ['$stateParams', '$scope', '$timeout', 'productService','$state','$http','Auth',
    function appointmentdetails($stateParams,$scope,$timeout,productService,$state,$http,Auth){
   
    $scope.userid = Auth.user;
    console.log($stateParams);
    $scope.stateParams = JSON.parse($stateParams.searchData);
    console.log($scope.stateParams.category);
    $scope.doctordetails = JSON.parse($stateParams.doctor);
    $scope.daytimedetails = JSON.parse($stateParams.data);
    console.log($scope.doctordetails);
     $scope.reasons = {};
    $scope.reasons.options = [{reason:"Special offer"},{reason:"Abdominal pain"},{reason:"Abnormal bleeding"},{reason:"Allergies"},{reason:"Anxiety"},{reason:"Burning w or urination"},{reason:"Chest pain"},{reason:"Constipation"},{reason:"Coughing"},{reason:"Cracked tooth"},{reason:"Crying"},{reason:"Dental pain"},{reason:"Depression"},{reason:"Diarrhea"},{reason:"Difficulty breath"},{reason:"Discoloration"},{reason:"Dizziness"},{reason:"Dryness"},{reason:"Erectile Dysfunction"},{reason:"Excessive thirst"},{reason:"Fibroids"},{reason:"Frequent bruising"},{reason:"Frequent urination"},{reason:"Genital discharge"},{reason:"Genital odor"},{reason:"Gum pain"},{reason:"Hair loss"},{reason:"Hay Fever"},{reason:"Heart burn"},{reason:"Heat or cold intolerance"},{reason:"Hives"},{reason:"I need braces"},{reason:"Incontinence"},{reason:"Infertility"},{reason:"Joint pain"},{reason:"Loss of hearing"},{reason:"Low libido"},{reason:"Lumps"},{reason:"Mole Changes"},{reason:"Muscle pain"},{reason:"Muscle weakness"},{reason:"Nausea"},{reason:"Nipple discharge"},{reason:"Numbness or tingling"},{reason:"Oily"},{reason:"Painful intercourse"},{reason:"Painful menstruation"},{reason:"Palpitations"},{reason:"Phlegm"},{reason:"Poor circulation"},{reason:"Postcoital bleeding"},{reason:"Rash"},{reason:"Regurgitation"},{reason:"STD"},{reason:"Seizures"},{reason:"Shortness of breath"},{reason:"Sinus problems"},{reason:"Skin changes"},{reason:"Sleep apnea"},{reason:"Sore throat"},{reason:"Swelling"},{reason:"Swollen glands"},{reason:"Teeth cleaning"},{reason:"Teeth whitening"},{reason:"Thoughts of suicide"},{reason:"Tinnitus or Ringing in ears"},{reason:"Urine retention"},{reason:"Vomiting"},{reason:"Wheezing"},{reason:"Wounds"}];
    $scope.typeVisit = {};
    $scope.typeVisit.options = [{type:"Phone",id:"Phone Consultation"},{type:"Video",id:"Online Exam Room"}];
    $scope.personaldetails = function(){
        var data = {visitreason : $scope.reasons.select , personalmsg :$scope.Personalmessage,type:$scope.visitTypeWhere};
        // productService.addreason(data);
        $scope.name = Auth.user.username;

       
        if($scope.name == '' ){
             var addStatedata = {doctor:JSON.stringify(JSON.parse($stateParams.doctor))
                ,data:JSON.stringify(JSON.parse($stateParams.data)),searchData:JSON.stringify(JSON.parse($stateParams.searchData)),
                personaldetails:JSON.stringify(data)
            }
             productService.addStatedata(addStatedata)
            $state.transitionTo("anon.appointment-signin",{
                  },{
                    reload: true,
                    notify: true
            });
        }
        else{
            // $scope.getUserinfo();
            $state.go("user.appointment-verify",({doctor:JSON.stringify(JSON.parse($stateParams.doctor))
                ,data:JSON.stringify(JSON.parse($stateParams.data)),searchData:JSON.stringify(JSON.parse($stateParams.searchData)),
                personaldetails:JSON.stringify(data)
            }));

           
            // $scope.initialize();
            
        }
    
    }
    $scope.visitType = function  (typeVisit) {
        $scope.visitTypeWhere = typeVisit;
    }
    // $scope.getUserinfo = function(){
    //     var url = '/v1/patient?email='+$scope.userid.email;
    //     $http.get(url).success(function(data){  
    //         console.log(data);
    //         $scope.daytimedetails.user = data;

    //     })
    //     .error(function(data, status, headers, config) {

    //     });
    //  }   
    // productService.addlocationdetails();
}]);
