var Mongoose = require('mongoose'),
	Schema = Mongoose.Schema;

var review = new Schema({
	referenceId: {type: String, require: true},
	patientEmail: {type: String, require: true},
	providerEmail: {type: String, require: true},
	providerName: {type: String, require: true},
	date: {type: Date, require: true},
	answer: {type: Array, require: true},
	average: {type: String, require: true},
	message: {type: String, require: true},
	status: {type: String, require: true},
	createdAt: {type: Date, default: Date.now()}
});

var review = Mongoose.model('review', review, 'review');

module.exports = {
	review: review
}