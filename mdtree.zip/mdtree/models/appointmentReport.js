var Mongoose = require('mongoose'),
	Schema = Mongoose.Schema;

var appointmentHistory = new Schema({
	date: {type: Date, required: true},
	provider: {type: String, required: true},
	name: {type: String, required: false},
	zip: {type: String, required: true},
	type: {type: String, required: true},
	total: {type: Number, default: 0, required: false},
	users: {type: Array, required: false}
});

var bookedHistory = Mongoose.model('appointmentHistory', appointmentHistory, 'appointmentHistory');

module.exports = {
	bookedHistory: bookedHistory
}