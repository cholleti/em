var Mongoose = require('mongoose'),
	Schema = Mongoose.Schema;

var searchResult = new Schema ({
	requestQuery: {
		category: {type: String, required: true},
		specialty: {type: String, required: true},
		insurance: {type: String, required: true},
		zip: {type: String, required: true}
	},
	result: {type: Array, required: true},
	createdAt: {type: Date, expires: 86400, default: Date.now()} //expire for 1day
});

var searchResult = Mongoose.model('searchResult', searchResult, 'searchResult');

module.exports = {
	searchResult: searchResult
};