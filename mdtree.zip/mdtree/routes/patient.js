var	Patient = require("../models/patient").Patient,
	patAppointments = require("../models/patientapptmnt").patientAppointments,
	SignUp = require("../models/signup").SignUp,
	Review = require("../models/review").review,
	providerDetails = require("../models/provdetails").Details,
	adminAuth = require('./config').auth.admin,
	Boom =  require("boom"),
	Joi = require("joi"),
	_ = require("underscore"),
	http = require('./config').http,
    OK = http.get('OK').value,
    formattedDate = require('./config').date,
	error = require('./config').errorMessage,
	status = require('./config').apptStatus;

var moment = require('moment');

module.exports = exports = function(server) {	
	exports.patient(server);
	exports.updatePatient(server);
	exports.appointmentHistory(server);
	exports.postRating(server);
	exports.getReview(server);
	exports.approveReview(server);
}

//to get patient information
exports.patient = function(server) {
	server.route({
		method: "GET",
		path: "/v1/patient",
		config: {
			validate: {
				query: {
					view: Joi.string(),
					email: Joi.string().email().required()
				}
			},
			auth: {
				mode: 'try',
				strategy: "session"
			},			
			handler: function(request, reply) {	
				Patient.findOne({"email": request.query.email}, function(err, patient) {
					if(err) 
						reply(Boom.forbidden(error(err)));
					if(!patient)						
						reply(Boom.notFound("No such patient"));
					if(patient) {	
						if(request.query.view != 'info' && request.query.view != undefined)		
							reply(Boom.forbidden('Unexpected view option'));
						if(request.query.view === 'info' && request.query.view != undefined) {
							var getPatient = {
								"gender": patient.gender,
								"email": patient.email,
								"phone": patient.phone
							}													
						}
						if(request.query.view === undefined) {
							var dob = formattedDate(patient.dob);
							var getPatient = {
								"username": patient.firstName,
								"lastName": patient.lastName,
								"gender": patient.gender,
								"dob": dob,
								"zipCode": patient.zipCode,
								"email": patient.email,
								"phone": patient.phone
							}							
						}	
						reply({patient:getPatient});					
					}
				});
			}
		}
	});
}

// to update patient information
exports.updatePatient = function(server) {
	server.route({
		method: "PUT",
		path: "/v1/updatePatient",
		config: {
			auth: 'session',			
			validate: {
				query: {
					email: Joi.string().email().required()
				},
				payload: {
					firstName: Joi.string().required(),
					lastName: Joi.string().required(),
					zipCode: Joi.string().required(),
					gender: Joi.string().required(),
					dob: Joi.string().required(),
					phone: Joi.string().min(10).max(15).required()
				}
			},
			handler: function(request, reply) {			
				var email = request.query.email;
				if(email != request.auth.credentials.profile.email) {
					reply(Boom.forbidden("Cannot change other's details"));
				}
				if(email === request.auth.credentials.profile.email) {					
					Patient.update({"email": request.query.email},
						{$set: {
								"firstName": request.payload.firstName,
								"lastName": request.payload.lastName,
								"zipCode": request.payload.zipCode,
								"gender": request.payload.gender,
								"dob": request.payload.dob,
								"phone": request.payload.phone,
								"email": request.query.email
							}
						},
						function(err, updatePatient) {
							if(err)	reply(Boom.forbidden(error(err)));
							if(updatePatient) {
								SignUp.update({"email": request.query.email}, 
									{$set: {"username": request.payload.firstName}}, 
									function(err, updated) {
										if(err) reply(Boom.forbidden(error(err)));
										if(updated) reply('Updated Successfully').code(OK);
									}
								);
							}
						}
					);
				}
			}
		}
	});
}

// listing appointment history of patient
exports.appointmentHistory = function(server) {
	server.route({
		method: 'GET',
		path: '/v1/appointmentHistory',
		config: {
			auth: 'session',
			validate:{
				query: {
					email: Joi.string().email().required(),
					date: Joi.date().required()
				}
			},
			handler: function(request, reply) {
				Date.prototype.today = function () { 
					return (((this.getMonth()+1) < 10)?"0":"") + (this.getMonth()+1) + "-"+ ((this.getDate() < 10)?"0":"") + this.getDate() +"-"+ this.getFullYear();
				};
				if(request.query.email != request.auth.credentials.profile.email)
					reply(Boom.forbidden("Cannot access other's details"));
				if(request.query.email === request.auth.credentials.profile.email) {
					var givenDate = moment(request.query.date);
					var givenDateNext = moment(givenDate).add('days', 1);

					patAppointments.find({"patient": request.query.email, "date": {$gte: givenDate.toDate(), $lt: givenDateNext.toDate()}, "status": {$ne: status.Cancel.string}}, function(err, getPatient) {
						if(err) reply(Boom.forbidden(error(err)));
						if(!getPatient) reply(Boom.notFound('No Appointments for the Date given'));
						if(getPatient) {
							var patientArray =[];
							_.each(getPatient, function(patient) {
								var details = {
									"date": (patient.date).today(),
									"time": patient.time,
									"provider": patient.prov,
									"providerEmail": patient.provEmail,											
									"location": patient.loc
								};
								if (patient.reason) {
									details.reason = patient.reason;
								}
								if (patient.type) {
									details.type = patient.type;
								}
								if (patient.offer) {
									details.offer = patient.offer;
								}
								patientArray.push(details);
							});
							reply({appointments:patientArray});
						}
					});
				}				
			}
		}
	});
};

// post rating
exports.postRating = function(server) {
	server.route({
		method: 'POST',
		path: '/v1/addRating',
		config: {
			validate: {
				query: {
					appointmentId: Joi.string().required()
				},
				payload: {
					answer: Joi.array().required(),
					message: Joi.string().required()
				}
			},
			handler: function(request, reply) {
				patAppointments.findOne({'_id': request.query.appointmentId}, function(err, details) {
					if(err)
						reply(Boom.forbidden(error(err)));
					else if(!details) 
						reply(Boom.notFound('No such appointment'));
					else if(details) {
						if(details.review == undefined) {
							if(request.payload.answer.length < 10)
								reply(Boom.forbidden('You have not given an answer for all the questions'));
							else {
								providerDetails.findOne({'email': details.provEmail}, function(err, provider) {
									if(err)
										reply(Boom.forbidden(error(err)));
									else if(!provider) 
										reply(Boom.notFound('No such provider'));
									else if(provider) {
										var total = _.reduce(request.payload.answer, function(memo, num){ return memo + num; }, 0);
										var average = (total / 10).toFixed(0);
										console.log('percentage ', total, average);
										var review = new Review();
										review.referenceId = request.query.appointmentId;
										review.patientEmail = details.patient;
										review.providerEmail = details.provEmail;
										review.providerName = details.prov;
										review.answer = request.payload.answer;
										review.average = average;
										review.message = request.payload.message;
										review.date = details.date;										
										review.status = 'pending';
										review.save(function(err, reviewAdded) {
											if(err)
												reply(Boom.forbidden(error(err)));
											else if(!reviewAdded)
												reply(Boom.forbidden('Not able to save your review'));
											else if(reviewAdded) {
												patAppointments.update({'_id': request.query.appointmentId}, {$set: {'review': 'done'}}, function(err, updatedReview) {
													if(err)
														reply(Boom.forbidden(error(err)));
													else if(!updatedReview)
														reply(Boom.forbidden('Not able to update review'));
													else if(updatedReview) {
														reply('Review updated successfully');
													}
												});
											}
										});
									}
								});
							}
						}
						else if(details.review != undefined) 
							reply(Boom.methodNotAllowed('You have already given an review for this appointment'));
					}
				})
			}
		}
	});
};

// get reviews
exports.getReview = function(server) {
	server.route({
		method: 'GET',
		path: '/v1/getReview',
		config: {
			auth: 'session',
			handler: function(request, reply) {
				var userRole = request.auth.credentials.role.title; 
				if( userRole === adminAuth.title ) {
					Review.find({'status': 'pending'}, function(err, reviewDetails) {
						if(err)
							reply(Boom.forbidden(error(err)));
						else if(!reviewDetails)
							reply(Boom.notFound('No pending review found'));
						else if(reviewDetails) {
							var result = [];
							if(reviewDetails.length > 0) {
								Date.prototype.today = function () { 
									return (((this.getMonth()+1) < 10)?"0":"") + (this.getMonth()+1) + "-"+ ((this.getDate() < 10)?"0":"") + this.getDate() +"-"+ this.getFullYear();
								}
								_.each(reviewDetails, function(review) {								
									var data = {
										referenceId: review.referenceId,
										provider: review.providerName,
										providerEmail: review.providerEmail,
										patientEmail: review.patientEmail,
										date: (review.date).today(),
										answer: review.answer,
										message: review.message,
										status: review.status
									}
									result.push(data);
								});		
								reply({reviews: result})					
							}
							else 
								reply({reviews: result})
						}
					});
				}
				else 
					reply(Boom.unauthorized('Not authorized to view reviews'));
			}
		}
	});
};

// approve reviews
exports.approveReview = function(server) {
	server.route({
		method: 'PUT',
		path: '/v1/approveReview',
		config: {
			auth: 'session',
			validate: {
				query: {
					referenceId: Joi.array().required()
				}
			},
			handler: function(request, reply) {
				var userRole = request.auth.credentials.role.title; 
				if( userRole === adminAuth.title ) {
					updateReview(0);
					function updateReview(i) {
						if(i == request.query.referenceId.length) {						
							reply('approved reviews');
						}
						else {						
							Review.findOne({'referenceId': request.query.referenceId[i], 'status': 'pending'}, function(err, getReview) {
								if(err)
									reply(Boom.forbidden(error(err)));
								else if(!getReview) {
									console.log('no review');
									updateReview(i+1);
								}
								else if(getReview) {
									Review.find({'providerEmail': getReview.providerEmail, 'review': 'done'}, {'_id': 0, 'average': 1}, function(err, totalRatings) {
										if(err)
											reply(Boom.forbidden(error(err)));
										else if(!totalRatings || totalRatings.length == 0) {
											console.log('not given');
											providerDetails.update({'email': getReview.providerEmail}, {$set: {'rating': getReview.average}}, function(err, provDetail) {
												if(err)
													reply(Boom.forbidden(error(err)));
												else if(!provDetail) {
													console.log('Not able to update');
													updateReview(i+1);
												}
												else if(provDetail) {												
													console.log('Ratings submitted successfully');
													Review.update({'referenceId': request.query.referenceId[i]}, {$set: {'status': 'approved'}}, function(err, updateStatus) {
														if(err)
															reply(Boom.forbidden(error(err)));
														else if(!updateStatus)
															console.log('Not able to update review');
														else if(updateStatus)
															console.log('Updated review');
													});
													updateReview(i+1);
												}
											});
										}
										else if(totalRatings.length > 0) {
											console.log('have rating', totalRatings);
											var rating = [];
											_.each(totalRatings, function(ratingg) {
												console.log('current rating ', ratingg.average, parseInt(ratingg.average));
												rating.push(parseInt(ratingg.average));
											});
											console.log('rating is ', rating);
											var ratings = _.reduce(rating, function(memo, num){ return memo + num; }, 0);
											var averageRating = ratings/totalRatings.length;
											console.log('ratings', averageRating);
											providerDetails.update({'email': getReview.providerEmail}, {$set: {'rating': averageRating}}, function(err, provDetail) {
												if(err)
													reply(Boom.forbidden(error(err)));
												else if(!provDetail) {
													console.log('Not able to update');
													updateReview(i+1);
												}
												else if(provDetail) {												
													console.log('Ratings submitted successfully');
													Review.update({'referenceId': request.query.referenceId[i]}, {$set: {'status': 'approved'}}, function(err, updateStatus) {
														if(err)
															reply(Boom.forbidden(error(err)));
														else if(!updateStatus)
															console.log('Not able to update review');
														else if(updateStatus)
															console.log('Updated review');
													});
													updateReview(i+1);
												}
											});
										}
									});
								}
							});
						}
					}
				}
				else 
					reply(Boom.unauthorized('Not authorized to approve reviews'));
			}
		}
	});
};