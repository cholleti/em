var Boom =  require("boom"),
	Joi = require("joi"),
	_ = require("underscore"),
	error = require('./config').errorMessage,
	slotStatus = require('./config').slotStatus,
	searchRadius = require('./config').radius,
	Result = require('../models/searchResult').searchResult,
	Zip = require("../models/zipcode").Zip,	
	Details = require("../models/provdetails").Details,	
	Appointments = require("../models/provappts").Appointments;

module.exports = exports = function(server) {
	exports.search(server);
};

// search providers with the basic requirement
exports.search = function(server) {
	server.route({
		method: "GET",
		path: "/v1/provider/search",
		config: {
			validate: {
				query: {
					specialty: Joi.string().required(),
					insurance: Joi.string(),
					zip: Joi.string().required(),
					category: Joi.string().required(),
					start: Joi.string(),
					count: Joi.string(),
					email: Joi.string(),
					gender: Joi.string(),
					languages: Joi.array(),
					name: Joi.string(),
					startindex: Joi.number(),
					count:Joi.number().integer(),
					start:Joi.number().integer()
				}
			}
		},
		handler: function(request, reply) {
			Date.prototype.today = function () { 
				return (((this.getMonth()+1) < 10)?"0":"") + (this.getMonth()+1) + "-"+ ((this.getDate() < 10)?"0":"") + this.getDate() +"-"+ this.getFullYear();
			}

			var searchZip = [];
			if(request.query.email) {
				searchZip.push(request.query.zip)
				check();
			}
			else {
				Zip.findOne({'ZIP': request.query.zip}, {'_id':0, 'LTTD':1, 'LGTD':1}, function(err, zip) {
					if(err)
						reply(Boom.forbidden(error(err)));
					else if(!zip) 
						reply(Boom.notFound('No such zipcode available'));
					else {
						var searchRange = (searchRadius/ 69.0);
						Zip.find({
							'LTTD': {
								$lte: searchRange + zip.LTTD, 
								$gte: zip.LTTD - searchRange
							},
							'LGTD': {
								$lte: searchRange + zip.LGTD,
								$gte: zip.LGTD - searchRange
							}
						}, {'_id':0, 'ZIP':1}, function(err, rangeZip) {
							if(err)
								reply(Boom.forbidden(error(err)));
							else if(!rangeZip || rangeZip.length <= 0)
								reply(Boom.notFound('No providers available in this zipcode'));
							else {
								_.each(rangeZip, function(singleZip, i) {
									if(i == rangeZip.length-1) {
										searchZip.push((singleZip.ZIP).toString());
										check();
									}
									else 
										searchZip.push((singleZip.ZIP).toString());
								});
							}
						});
					}				
				});
			}
			var start = 0, count = 30, counting = 30, n = 0;			
			var today = new Date();
			var	dates=[], resultantArray=[], appointment=[],  apptDate=[], apptSlot=[], chkdates=[], timeschedule=[];
			var	locId, count, providers = [], err, dateCount, queryString, i, j, queryparam, getproviders =[], locationArray = [];			
			if(request.query.email === undefined)  
				dateCount=3;
			if(request.query.email != undefined) {
				dateCount=5;				
			}
			var dates=[];
			var today = new Date();
			var startindex, dateindex;
			if(request.query.startindex === undefined)
				dateindex = 0;
			if(request.query.startindex != undefined)
				dateindex = parseInt(dateCount) * request.query.startindex;
			for (var i=0; i<dateCount; i++) {
				var calcdate = new Date();
				var formatDate = "";
				calcdate.setDate(today.getDate()+(dateindex+i));								
				if (calcdate.getMonth()<9) {
					formatDate += "0" + (calcdate.getMonth()+1);
				} else {
					formatDate += (calcdate.getMonth()+1);
				}
				if (calcdate.getDate()<10) {
					formatDate += "-" +"0" + calcdate.getDate();
				} else {
					formatDate += "-" +calcdate.getDate();
				}
				formatDate += "-" + calcdate.getFullYear();
				dates.push(formatDate);		
			}
			var firstDay = new Date(dates[0]);
			var lastDay = new Date(dates[dates.length-1]);
			lastDay.setHours(23);
			lastDay.setMinutes(59);
			lastDay.setSeconds(59);

			function check() {
				var url = require('url'),
					url_parts = url.parse(request.url, true),
					query = url_parts.query,
					newquery,
					languages = [];
				if(request.query.languages != undefined) {
					for (var i=0; i< (request.query.languages).length; i++) 
						languages.push((request.query.languages)[i].toLowerCase());
				}
				var insurance = [];
				if(query.insurance != undefined && query.insurance != 'insure_1') {
					insurance.push('insure_1');
					insurance.push(query.insurance);
				}
				else if(query.insurance === undefined || query.insurance === 'insure_1') 
					insurance.push('insure_1');

				if(query.name != undefined) {
					newquery = {
						"category": query.category,
						"specialty": query.specialty,
						"location.zip": {$in: searchZip},
						"insurance": {$in:insurance},
						"languages": {$in:languages},
						"gender": query.gender,
						$or: [{"firstName": {$regex: ".*"+query.name+".*"}},{"lastName": {$regex: ".*"+query.name+".*"}}]
					}
				}
				if(query.name === undefined) {
					newquery = {
						"category": query.category,
						"specialty": query.specialty,
						"location.zip": {$in: searchZip},						
						"insurance": {$in:insurance},
						"languages": {$in: languages},
						"gender": query.gender
					}
				}
				if(query.insurance === undefined)
					delete newquery.insurance;
				if(query.insurance != undefined)
					newquery.insurance = newquery.insurance;
				if(query.languages === undefined)
					delete newquery.languages;
				if(query.email === undefined)
					delete newquery.email;								
				if(query.gender === undefined)
					delete newquery.gender;
				if(query.name === undefined)
					delete newquery.firstName;
				if(query.name === undefined)
					delete newquery.lastName;	
				delete newquery.start;
				delete newquery.count;
				if(request.query.start != undefined) 
					start = request.query.start;
				if(request.query.count != undefined) {
					count = (request.query.count);
					counting = parseInt(start)+parseInt(request.query.count);
				}
				if(query != undefined) {
					if(query.email != undefined) {
						n = (request.query.email).search('@');
						if(n == -1) {
							delete newquery.email;	
							newquery.npi = query.email;
						}
						else
							newquery.email = query.email;
					}
					Result.aggregate(
						[
							{$match: 
								{
									'requestQuery.zip': query.zip, 
									'requestQuery.category': query.category, 
									'requestQuery.specialty': query.specialty, 
									'requestQuery.insurance': query.insurance
								}
							} 
							, {$project: 
								{
									'_id': 0, 'requestQuery': 1, 'result': 1,  'total': {$size: '$result'} 
								}
							} 
						], 
						function(err, searchData) {
							if(err)
								reply(Boom.forbidden(error(err)));
							else if(searchData.length > 0) {
								var total = searchData[0].total;
								if(counting > total) {
									count = count;
									if(start > 0) {
										count = start + count;
									}
								}
								else {									
									if(start > 0) {
										count = start + count;
									}
									count = count;
								}
								searchData = (searchData[0].result).slice(start, count);
								getDetails(searchData, total);
							}
							else if(searchData.length <= 0) {
								// console.log('newquery to find is ', newquery);
								Details.find(newquery
									, {'_id':0, 'email':1, 'npi':1, 'title':1, 'firstName':1, 'lastName':1, 'image':1, 'location.$':1, 'subscription':1, 'cash':1, 'offer':1, 'webSite':1, 'rating':1}
									).exec(function(err, getproviders) {
									if(err)
										reply(Boom.forbidden(error(err)));
									if(getproviders.length === 0) 
										reply(Boom.notFound("No exact matching"));
									if(getproviders.length != 0) {	
										var getproviderss = [];
										getproviderss = getproviders;
										getproviderss = _.shuffle(getproviders);					
										var resultProvider = [];
										var goldProviders = [], silverProviders = [], bronzeProviders = [], freeProviders =[], randomArray =[];	
										//grouping providers with their plan type
										var group = _.groupBy(getproviderss, function(getprovider) {
											return (getprovider.subscription.planType)
										});	
										goldProviders = (group["gold"]);
										silverProviders = (group["silver"]);
										bronzeProviders = (group["bronze"]);
										freeProviders = (group["free"]);
										checkData();
										function checkData() {
											if(randomArray.length == getproviderss.length) {
												_.each(randomArray, function(singlePlan, index) {
													if(index == randomArray.length - 1) {
														resultProvider.push(singlePlan);
														var search = new Result();
														search.requestQuery.category = query.category;
														search.requestQuery.specialty = query.specialty;
														search.requestQuery.insurance = query.insurance;
														search.requestQuery.zip = query.zip;
														search.result = resultProvider;
														search.save(function(err, savedData) {
															if(err)
																console.log('error in saving into searchResult');
															else if(!savedData)
																console.log('not able to save the data');
															else if(savedData)
																console.log('data saved');
														})
														if(counting > resultProvider.length)
															count = resultProvider.length;
														else
															count = count;
														getDetails(resultProvider, resultProvider.length);
													}
													else {
														resultProvider.push(singlePlan);
													}
												});
											}
											else {
												if(goldProviders !=undefined) {
													for(var index=0; index<goldProviders.length; index++) {						
														if(goldProviders[index] != undefined) 
															randomArray.push(goldProviders[index]);	
													}
												}
												
												if(silverProviders != undefined) {
													for(var index=0; index<silverProviders.length; index++) {
														if(silverProviders[index] != undefined) 
															randomArray.push(silverProviders[index]);
													}
												}
												if(bronzeProviders != undefined) {
													for(var index=0; index<bronzeProviders.length; index++){
														if(bronzeProviders[index] != undefined) 
															randomArray.push(bronzeProviders[index]);
													}
												}
												if(freeProviders != undefined) {
													for(var index=0; index<freeProviders.length; index++) {
														if(freeProviders[index] != undefined) 
															randomArray.push(freeProviders[index]);
													}
												}
												checkData();
											}
										}
									}
								});
							}
						}
					);
				}	
			}
			function getDetails(providers, length) {
				locationArray = [];
				if(!request.query.email) {
					var checkIndex = start+count;
					for(var i = start; i < checkIndex; i++) {
						if(providers[i] != undefined)
							locationArray.push(providers[i].location[0].locId)
					}
				}
				else {
					locationArray.push(providers[0].location[0].locId);
				}
				Appointments.find({"loc": {$in: locationArray}, "date":{$gte: firstDay, $lte: lastDay}},
					{"date":1, "slots":1, "_id":0, "loc":1, "specialOffer":1},
					{sort:({date:1})}, function(err, apptss) { 
						if(err)
							reply(Boom.forbidden(error(err)));
						if(apptss) {
							var appointment = [];
							var modifySlots = [];
							providerDetail(0);
							function providerDetail(startIndex) {
								var appointment = [];
								var modifySlots = [];
								if(startIndex === providers.length || count === resultantArray.length) {
									// console.log('\n\n Final result ', JSON.stringify({providers: resultantArray, start: start, count: resultantArray.length, total:length}));
									reply({providers: resultantArray, start: start, count: resultantArray.length, total:length});
								}
								else {
									var appts = [];
									_.each(apptss, function(appointmnt) {
										if(appointmnt.loc === providers[startIndex].location[0].locId) {
											appts.push(appointmnt);
										}
									});
									_.each(dates, function(index) {
										var slot = [], title, description;
										var slotJson = {};
										var time = [], timeTaken;												
										function getSlot(id) {
										    return _.find(appts, function(appt) {
										    	var compareDate = (appt.date).today();
										    	function sortByTime(array, key) {
												    return array.sort(function(a, b) { 
												        var x = new Date('01-01-1970 ' + a[key]); 						        
												        var y = new Date('01-01-1970 ' + b[key]);
												        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
												    });
												}
										    	var appointmentSlot = sortByTime(appt.slots, 'from');
										    	if(compareDate === id) {
										    		function getstatus(status) {
														return _.find(appointmentSlot, function(slot) {	
															//resetting time slot blocked by other's if time out															
															if(slot.status == status) {
																var startTime = slot.at;
																var	today = new Date(),
																	currentTime = ((today.getHours()+1)*60*60)+((today.getMinutes()+1)*60)+ (today.getSeconds()+1);
																timeTaken = Math.floor(Math.abs(currentTime - startTime)/60);
																if(timeTaken > slotStatus.Time.value) {
																	slot.status = slotStatus.Available.string;
																	time.push(slot.from);																			
																}
															}																	
															if(slot.from === appointmentSlot[appointmentSlot.length-1].from) {
																if(time.length > 0) {
																	slotJson.loc = appt.loc;
																	slotJson.date = compareDate;
																	slotJson.time = time;
																}
																modifySlots.push(slotJson);
															}
														});
													}
													var slots = getstatus(slotStatus.Blocked.string);	
											    	_.each(modifySlots, function(modifySlot) {
											    		_.each(modifySlot.time, function(slotTime) {
															Appointments.update({'loc': modifySlot.loc, 'date': modifySlot.date, 'slots.from': slotTime}, 
															    {$set: {'slots.$.status': slotStatus.Available.string}}, function(err, updated) {
															    	if(err)
															    		reply(Boom.forbidden(error(err)));
															    	if(updated) {
															    		// count++;
															    		console.log('updated ');
															    	}
															    }
															);
														});
											    	});
											    	return compareDate == id;
										    	}
										    });
										}

										if(getSlot(index) === undefined)
											slot = [];
										else {
											slot = getSlot(index).slots;
											if(getSlot(index).specialOffer.title && slot.length > 0) {
												title = getSlot(index).specialOffer.title;
												description = getSlot(index).specialOffer.description;
											}
										}
										var apptSchedule = {
											'date': index,
											'slots': slot,
											'title': title,
											'description': description
										}
										appointment.push(apptSchedule);
									});

									if(dateCount === 3) {
										var emailId;
										if(providers[startIndex].email == undefined) 
											emailId = providers[startIndex].npi;
										else 
											emailId = providers[startIndex].email;
										var result = {
											"email": emailId,												
											"name": providers[startIndex].title+" "+providers[startIndex].firstName+" "+providers[startIndex].lastName,
											"image": providers[startIndex].image,	
											"locationId": providers[startIndex].location[0].locId,						
											"address": providers[startIndex].location[0].address,
											"city": providers[startIndex].location[0].city,
											"state": providers[startIndex].location[0].state,
											"zip": providers[startIndex].location[0].zip,
											"phone": providers[startIndex].location[0].phone1,
											"appointmentSchedules": appointment,
											"plan": providers[startIndex].subscription.planType,
											"cash": providers[startIndex].cash,
								            "offerStmt": providers[startIndex].offer,
								            "website": providers[startIndex].webSite,
								            "rating": providers[startIndex].rating
										}	
										resultantArray.push(result);
										providerDetail(startIndex + 1);
									}
									if(dateCount === 5) {
										var email;
										if(providers[startIndex].email == undefined || !providers[startIndex].email)
											email = providers[startIndex].npi;
										else 
											email = providers[startIndex].email;												
										var result;
										if(request.query.startindex) {
											result = {
												"appointmentSchedules": appointment
											}
										}
										else {
											result = {
												"email": email,												
												"name": providers[startIndex].title+" "+providers[startIndex].firstName+" "+providers[startIndex].lastName,
												"image": providers[startIndex].image,
												"locationId": providers[0].location[0].locId,							
												"address": providers[0].location[0].address,
												"city": providers[0].location[0].city,
												"state": providers[0].location[0].state,
												"zip": providers[0].location[0].zip,
												"phone": providers[0].location[0].phone1,
												"appointmentSchedules": appointment,
												"plan": providers[startIndex].subscription.planType,
												"cash": providers[startIndex].cash,
									            "offerStmt": providers[startIndex].offer,
									            "website": providers[startIndex].webSite,
									            "rating": providers[startIndex].rating
											}
										}
										// console.log('\n\n Final result ', JSON.stringify(({providers: result, total:length})));
										reply({provider: result, total:length});
									}
								}
							}								
						}									
					}								
				);			
			}
		}
	});
};