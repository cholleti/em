var Enum = require('enum');
var error = function getErrorMessageFrom(err) {
    var errorMessage = '';
    if (err.errors) {
        for (var prop in err.errors) {
            if(err.errors.hasOwnProperty(prop)) {
                errorMessage += err.errors[prop].message + ' '
            }
        }
    } else {
        errorMessage = err.message;
    }
    return errorMessage;
};

var status = {
    Available: {
        value: 0,
        string: 'available'
    },
    Booked: {
        value: 1,
        string: 'booked'
    },
    NoShow: {
        value: 2,
        string: 'noshow'
    },
    Done: {
        value: 3,
        string: 'done'
    },
    Cancel: {
        value: 4,
        string: 'cancel'
    }
};

var cookie = new Enum({
    "cookieName": "sid-mdTree",
    "password": "mdTree",
    "encoding": "iron"
},
{
    "name": "cookie"
});

var auth = {
    patient: {
        'bitMask': 2,
        'title': 'patient'
    }, 
    provider: {
        'bitMask':2,
        'title': 'provider'
    }, 
    admin: {
        'bitMask': 4,
        'title': 'admin'
    },
    user: {
        'title': 'user'
    },
    crypt: {
        'salt': 5
    }
};

var http = new Enum({
    'OK': 200,
    'Created': 201,
    'Accepted': 202
}, {'name':'http'});

var formattedDate = function(date) {
    var date = new Date(date);
    var formatDate="";
    if (date.getMonth()<9) {
        formatDate += "0" + (date.getMonth()+1);
    } else {
        formatDate += (date.getMonth()+1);
    }
    if (date.getDate()<10) {
        formatDate += "-" +"0" + date.getDate();
    } else {
        formatDate += "-" +date.getDate();
    }
    formatDate += "-" + date.getFullYear();
    return formatDate;
};

var sendMail = function() {
    var Mailgun = require('mailgun-js');
    var api_key = 'key-32c840d1575c3584ca122a0607ad8618';
    var domain = 'sandboxf200c276c3f449dfb7f547030d42aa12.mailgun.org';
    var mailgun = new Mailgun({apiKey: api_key, domain: domain});
    return { 
        mail: function (to, subject, text, callback) {
            var from_who = 'mdTree <no-reply@mdtree.com>'; 

            var data = {
                from: from_who,
                to: to,
                subject: subject,
                text: text+'\n \n \nBy \nMDTree Team. ' 
            }
            mailgun.messages().send(data, function (err, body) {
                if (err) {
                    console.log("got an error: ", err);
                }
                else {
                    console.log(body);
                    var result = 'Mail sent successfully';
                    console.log('returning from method is ',result);
                    callback(result);
                }
            });
        },
        templates: function (data, callback) {           
            
            mailgun.messages().send(data, function (err, body) {
                if (err) {
                    console.log("got an error: ", err);
                }
                else {
                    var result = 'Mail sent successfully';
                    callback(result);
                }
            });
        }
    }
}();

module.exports = {
    errorMessage: error,
    apptStatus: status,
    cookie: cookie,
    auth: auth,
    http: http,
    sendingMail: sendMail,
    date: formattedDate
};

