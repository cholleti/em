var	Details = require("../models/provdetails").Details,
	Appointments = require("../models/provappts").Appointments,
	Provider = require("../models/provdetails").Details,
	SignUp = require("../models/signup").SignUp,
	Boom =  require("boom"),
	Joi = require("joi"),
	Fs = require('fs'),
	_ = require("underscore"),
	status = require('./config').apptStatus,
	http = require('./config').http,
    OK = http.get('OK').value,
    formattedDate = require('./config').date,
	error = require('./config').errorMessage;

module.exports = exports = function(server) {
	exports.updateStatus(server);	
	exports.image(server);
	exports.getdetails(server);
	exports.updatedetails(server);
	exports.views(server);
	exports.offer(server);
	exports.slottedDate(server);
}

exports.updateStatus = function(server) {
	server.route({
		method: "PUT",
		path: "/v1/updateStatus",
		config:{
			auth: "session",
			validate: {
				payload: {
					provideremail: Joi.string().email().required(),
					date: Joi.string().required(),
					location: Joi.string().required(),
					slot: Joi.string().required(),
					status: Joi.string().required(),
					reason: Joi.string()
				}
			},
			handler: function(request, reply) {
				var email = request.payload.provideremail;
				if(email != request.auth.credentials.profile.email) {
					reply(Boom.forbidden("Cannot change other's status"));
				}
				if(email === request.auth.credentials.profile.email) {
					Provider.findOne({"email": request.payload.provideremail}, function(err, getProvider) {
						if(err)
							reply(Boom.forbidden(error(err)));
						if(!getProvider)
							reply(Boom.notFound("No such provider"));
						if(getProvider) {
							var a =request.payload.status;
							var newStatus;
							if(a != 'NoShow' && a != 'Done' && a != 'Booked' && a != 'Available' && a!= 'Cancel')
								reply(Boom.forbidden("Enter valid status"));
							if(a === 'NoShow' || a === 'Done' || a === 'Booked' || a === 'Available' || a === 'Cancel') {
								if(a === 'NoShow')
									newStatus = status.NoShow.string;
								if(a === 'Done')
									newStatus = status.Done.string;						
								if(a === 'Booked')
									newStatus = status.Booked.string;
								if(a === 'Available')
									newStatus = status.Available.string;								
								if(a === 'Cancel') {							
									newStatus = status.Available.string;
									Appointments.findOne({"prov": request.payload.provideremail, "date": request.payload.date, 
										"loc": request.payload.location, "slots.from": request.payload.slot},{"slots.$.patient":1},
										function(err, patient) {
										 	if(err)								 		
												reply(Boom.forbidden(error(err)))
											if(!patient)
												reply(Boom.notFound("No exact match"));
											if(patient) {
												if(patient.slots[0].patient === undefined) {
													reply(Boom.forbidden('There is no appointment booked in this slot'));
												}
												var patientdetail;
												if(request.payload.reason === undefined)
													reply(Boom.forbidden('Reason is required for cancel'));
												if(patient.slots[0].patient != undefined) {										
													if(request.payload.reason != undefined) {
														patientdetail = patient.slots[0].patient;											
														patientdetail.reason = request.payload.reason;										
													}		
												}
												Appointments.update({"prov": request.payload.provideremail, "date": request.payload.date, 
													"loc": request.payload.location, "slots.from": request.payload.slot}, 
													{$set: {"slots.$.status": newStatus, "slots.$.slotStatus": newStatus, "slots.$.cancelled": patientdetail}},													
													function(err, update) {
														if(err)
															reply(Boom.forbidden(error(err)))
														if(!update)
															reply(Boom.notFound("No exact match"));
														if(update) {	
															Appointments.update({"prov": request.payload.provideremail, "date": request.payload.date, 
																"loc": request.payload.location, "slots.from": request.payload.slot}, 
																{$unset: {"slots.$.patient":1}}, function(err, removed) {
																	if(err)
																		reply(Boom.forbidden(error(err)));
																	if(removed)				
																		reply("Cancelled successfully");		
																}
															);	
														}
													}
												);
												
											}
										} 
									);	
								}
								Appointments.update({"prov": request.payload.provideremail, "date": request.payload.date, 
									"loc": request.payload.location, "slots.from": request.payload.slot}, 
									{$set: {"slots.$.status": newStatus}},
									function(err, updated) {
										if(err)
											reply(Boom.forbidden(error(err)))
										if(!updated)
											reply(Boom.notFound("No exact match"));
										if(updated) 
											reply("Status updated successfully");
									}
								);
							}						
						}
					});
				}				
			}
		}
	});
}

exports.image = function(server) {
	server.route({
		method: "PUT",
		path: "/v1/imageupload",		
		config: {				
			auth: "session",			
			payload: {
				output: 'file',
		        maxBytes: 2097152,
		        uploads: './temp',
		        parse: true,
			},		
			validate: {
				payload: {
					imageFile: Joi.object().required(),
					email: Joi.string().email().required()
				}
			},
			handler: function(request, reply) {
				var user = new Provider(),
					file,
					email = request.payload.email;
				if(email != request.auth.credentials.profile.email) {
					reply(Boom.forbidden("Cannot change other's image"));
				}
				if(email === request.auth.credentials.profile.email) {				
					Provider.findOne({"email": email}, function(err, getProvider) {
						if(err)
							reply(Boom.forbidden(error(err)));
						if(!getProvider) {
							file = request.payload.imageFile;
							Fs.unlink(file.path);
							reply(Boom.notFound("No such user"));
						}
						if(getProvider) {							
							if (request.payload.imageFile) {
						        file = request.payload.imageFile;
						        var extn = (file.filename).substr((file.filename).indexOf('.')+1),
						        	path = (file.path).substr((file.path).indexOf('/')+1),
						    		filename = path+'.'+extn;
						        Fs.rename(file.path, './userimage/'+filename, function(err) {
						            if (err) throw err;
						        });		   
						        Provider.update({"email": email}, {$set: {"image": './userimage/'+filename}}, function(err, updated) {
						        	if(err)
						        		reply(Boom.forbidden(error(err)));
						        	if(updated) {
						        		if(getProvider.image != undefined)
						        			Fs.unlink(getProvider.image);
						        		reply('Updated Successfully').code(OK);
						        	}
						        });
						    }
						}						
					});	
				}					
			}
		}
	});
};

exports.views = function(server) {
	server.route({
		method: "GET",
		path: "/v1/getslot",
		config: {
			validate: {
				query: {
					view: Joi.string().required(),
					locId: Joi.string().required(),
					email: Joi.string().email().required(),
					startindex: Joi.number(),
					date: Joi.string()
				}
			},
			handler: function(request, reply) {
				var view, dates=[],
					today = new Date(), calcdate = new Date(),
					startindex, dateindex =0;

				if(request.query.view != 'daily'  && request.query.view != 'weekly')
					reply(Boom.notFound("Invalid view request"));
				if(request.query.view === 'daily') {
					view =1;						
					if((request.query.startindex === undefined) || (request.query.startindex != undefined && request.query.view === 'daily'))
						dateindex = 0;		
					if(request.query.date === undefined) 
						today = new Date();
					if(request.query.date != undefined)
						today = new Date(request.query.date);					
					var formatDate = "";
					// var calcdate = new Date();
					// calcdate.setDate(today.getDate()+(dateindex));
					// today.setDate(today.getDate()+i);
					
					if (today.getMonth()<9) {
						formatDate += "0" + (today.getMonth()+1);
					} else {
						formatDate += (today.getMonth()+1);
					}
					if (today.getDate()<10) {
						formatDate += "-" +"0" + today.getDate();
					} else {
						formatDate += "-" +today.getDate();
					}
					formatDate += "-" + today.getFullYear();
					dates.push(formatDate);					
				}
				if(request.query.view === 'weekly') {
					view =7;
					if(request.query.date === undefined) 
						today = new Date();
					if(request.query.date != undefined)
						today = new Date(request.query.date);
					var firstday = new Date(today.setDate(today.getDate() - today.getDay())),
						lastday = new Date(today.setDate(today.getDate() - today.getDay()+6));
					if(request.query.startindex != undefined && request.query.view === 'weekly')
						dateindex = parseInt(view) * request.query.startindex;
					for (var i=0; i<view; i++) {						
						var formatDate = "";												
						console.log('i is', i);
						if(i === 0 ) {
							calcdate = firstday;
							calcdate.setDate(calcdate.getDate()+(dateindex+i));
						}
						else
							calcdate.setDate(calcdate.getDate()+1);	
						
						if (calcdate.getMonth()<9) {
							formatDate += "0" + (calcdate.getMonth()+1);
						} else {
							formatDate += (calcdate.getMonth()+1);
						}
						if (calcdate.getDate()<10) {
							formatDate += "-" +"0" + calcdate.getDate();
						} else {
							formatDate += "-" +calcdate.getDate();
						}
						formatDate += "-" + calcdate.getFullYear();
						dates.push(formatDate);								
					}	
				}
				
				Appointments.find({"prov": request.query.email, "loc": request.query.locId, "date":{$in: dates}},
					{"date":1, "slots.status":1, "slots.from":1, "slots.to":1, "slots.patient":1, "_id":0},
					{sort:({date:1})}, function(err, provAppts) {
						appointments =[];
						if(err)
							reply(Boom.forbidden(error(err)));
						if(!provAppts) 
							reply(Boom.notFound("No such provider in this location"));
						if(provAppts) {
							if(provAppts.length === 0) {
								appointment=[];
								for( var k=0; k<dates.length;k++) {																										
									var slot=[];
									var apptSchedule = {
										"date": dates[k],
										"slots": slot
									}	
									appointments.push(apptSchedule);												
								}
							}
							if(provAppts.length != 0) {	
								appointments =[];																						
								var len = provAppts.length
								for(var m=0; m< dates.length; m++) {
									var apptSchedule ={};													
									for(var n=0; n<provAppts.length; n++) {
										if(dates[m] === provAppts[n].date) {
											apptSchedule = {
												"date": dates[m],
												"slots": provAppts[n].slots
											}
											appointments.push(apptSchedule);
											provAppts.splice(n, 1);
											break;
										}
										if(dates[m] != provAppts[n].date) {
											var slot=[];
											apptSchedule = {
												"date": dates[m],
												"slots": slot
											}	
											appointments.push(apptSchedule);
											break;
										}
									}									
									if(dates[m] != apptSchedule.date ) {
										var slot=[];
										var apptSchedule = {
											"date": dates[m],
											"slots": slot
										}	
										appointments.push(apptSchedule);
									}
								}
							}
							if(request.query.view === 'daily')
								reply({slot:appointments[0]});
							if(request.query.view === 'weekly')
								reply({slots:appointments});
						}						
					}
				);				
			}
		}
	});
}

exports.getdetails = function(server) {
	server.route({
		method: "GET",
		path: "/v1/provider",
		config: {
			validate: {
				query: {
					type: Joi.string(),
					locId: Joi.string(),
					email: Joi.string().email().required(),
					startindex: Joi.number(),
					getLocation: Joi.string()
				}				
			},
			handler: function(request, reply) {
				var i, j, count, appointments =[], location=[], apptDate = [], apptSlot=[], chkdates=[], locationArray=[], getProvider, loc;
				function calclocation(j) {
					if( j < (getProvider.location).length) {
						count =j;					
						
						if(request.query.getLocation === undefined) 
							loc = getProvider.location[j].locId;
						else 
							loc = request.query.getLocation;

						console.log('query to find is ', JSON.stringify(loc));
						Appointments.find({"prov": request.query.email, "loc": loc, "date":{$in: dates}},
							{"date":1, "slots.status":1, "slots.from":1, "slots.patient":1, "_id":0},
							{sort:({date:1})}, function(err, provAppts) {
								if(err)
									reply(Boom.forbidden(error(err)));
								if(!provAppts) 
									reply(Boom.notFound("No such provider in this location"));
								if(provAppts) {
									if(provAppts.length === 0) {
										appointments=[];
										for( var k=0; k<dates.length;k++) {																										
											var slot=[],
												apptSchedule = {
												"date": dates[k],
												"slots": slot
											}	
											appointments.push(apptSchedule);												
										}												
									}
									if(provAppts.length != 0) {	
										appointments =[];																						
										var len = provAppts.length
										for(var m=0; m< dates.length; m++) {
											var apptSchedule ={};													
											for(var n=0; n<provAppts.length; n++) {
												if(dates[m] === provAppts[n].date) {
													apptSchedule = {
														"date": dates[m],
														"slots": provAppts[n].slots
													}
													appointments.push(apptSchedule);
													provAppts.splice(n, 1);
													break;
												}
												if(dates[m] != provAppts[n].date) {
													var slot=[];
													apptSchedule = {
														"date": dates[m],
														"slots": slot
													}	
													appointments.push(apptSchedule);
													break;
												}
											}													
											if(dates[m] != apptSchedule.date ) {
												var slot=[];
												var apptSchedule = {
													"date": dates[m],
													"slots": slot
												}	
												appointments.push(apptSchedule);
											}
										}
									}
									var location = {
										"practiceName": getProvider.location[count].practiceName,
										"locationId": getProvider.location[count].locId,
										"address": getProvider.location[count].address,
										"city": getProvider.location[count].city,
										"state": getProvider.location[count].state,
										"zip": getProvider.location[count].zip,
										"phone1": getProvider.location[count].phone1,
										"phone2": getProvider.location[count].phone2,
										"fax": getProvider.location[count].fax,
										"appointmentSchedules": appointments
									}
									locationArray.push(location);
									if(request.query.getLocation === undefined) 
										calclocation(count+1);
									else
										calclocation(getProvider.location.length);
								}
							}
						);									
					}	
					if( j >= (getProvider.location).length) {						
						display();
					}
				}
				function display() {
					var primaryLocation = {
						address: getProvider.location[0].address+','+getProvider.location[0].city,
						state: getProvider.location[0].city
					}
					var result = {
						category: getProvider.category,
						specialty: getProvider.specialty,
						name: getProvider.title+" "+getProvider.firstName+" "+getProvider.lastName,
						dob: getProvider.dob,
						image: getProvider.image,
						primarylocation: primaryLocation,
						zipCode: getProvider.zipCode,
						email: getProvider.email,
						webSite: getProvider.webSite,
						notification: getProvider.notification,
						cash: getProvider.cash,
						cancellationNumber: getProvider.cancellationNumber,
						locations: locationArray,
						school: getProvider.school,
						residency: getProvider.residency,
						fellowship: getProvider.fellowship,
						affilliation: getProvider.affilliation,
						languages: getProvider.languages,
						insurance: getProvider.insurance,
						statement: getProvider.statement,	
						// appointmentSchedules: appointments								
					}																				
					reply({provider:result});
				}
				if(request.query.type === undefined) {					
					var dates=[],
						today = new Date(),
						startindex, 
						dateindex;
					if(request.query.startindex === undefined)
						dateindex = 0*7;
					if(request.query.startindex != undefined)
						dateindex = 7 * request.query.startindex;
					for (var i=0; i<7; i++) {
						var formatDate = "";
						var calcdate = new Date();
						calcdate.setDate(today.getDate()+(dateindex+i));						
						if (calcdate.getMonth()<9) {
							formatDate += "0" + (calcdate.getMonth()+1);
						} else {
							formatDate += (calcdate.getMonth()+1);
						}
						if (calcdate.getDate()<10) {
							formatDate += "-" +"0" + calcdate.getDate();
						} else {
							formatDate += "-" +calcdate.getDate();
						}
						formatDate += "-" + calcdate.getFullYear();
						dates.push(formatDate);
					}					
					Details.findOne({"email": request.query.email}, function(err, Provider) {
						if(err)
							reply(Boom.forbidden(error(err)))
						if(!Provider)
							reply(Boom.notFound("No such user"));
						if(Provider) {
							getProvider = Provider;							
							calclocation(0);
													
						}
					});
				}
				
				if(request.query.type === 'personal') {
					Details.findOne({"email": request.query.email}, function(err, getProvider) {
						if(err)
							reply(Boom.forbidden(error(err)));
						if(!getProvider)
							reply(Boom.notFound("No such provider registered with us"));
						if(getProvider) {
							var dob = formattedDate(getProvider.dob);
							var result = {
								category: getProvider.category,
								specialty: getProvider.specialty,
								title: getProvider.title,
								firstName: getProvider.firstName,
								lastName: getProvider.lastName,
								gender: getProvider.gender,
								dob: dob,
								zipCode: getProvider.zipCode,
								email: getProvider.email,
								webSite: getProvider.webSite,
								notification: getProvider.notification,
								cash: getProvider.cash,
								offer: getProvider.offer,
								cancellationNumber: getProvider.cancellationNumber
							}
							reply({providerDetails:result});
						}
					});
				}
				if(request.query.type === 'location') {
					Details.findOne({"email": request.query.email, "location.locId": request.query.locId},
						{'location':1, '_id':0}, function(err, getProvider) {
							if(err)
								reply(Boom.forbidden(error(err)));
							if(!getProvider)
								reply(Boom.notFound("No such location for this provider"));
							if(getProvider) {								
								for(var i =0; i<(getProvider.location).length; i++) {	
									if(getProvider.location[i].locId === request.query.locId) {
										var result = {												
											practiceName: getProvider.location[i].practiceName,
											address: getProvider.location[i].address,
											city: getProvider.location[i].city,
											state: getProvider.location[i].state,
											zip: getProvider.location[i].zip,
											phone1: getProvider.location[i].phone1,
											phone2: getProvider.location[i].phone2,
											fax: getProvider.location[i].fax
										}
										reply({providerLocation:result});
									}									
								}
							}
						}
					);
				}
				if(request.query.type === 'alllocation') {
					Details.findOne({"email": request.query.email}, function(err, getProvider) {
							if(err)
								reply(Boom.forbidden(error(err)));
							if(!getProvider)
								reply(Boom.notFound("No such location for this provider"));
							if(getProvider) {
								var locationArray=[];
								for(var i =0; i<(getProvider.location).length; i++) {										
									var result = {																								
										address: getProvider.location[i].address+','+getProvider.location[i].city+','+getProvider.location[i].state+','+getProvider.location[i].zip,
										locId: getProvider.location[i].locId												
									}
									locationArray.push(result);										
								}	
								reply({providerLocations:locationArray});							
							}
						}
					);
				}

				if(request.query.type === 'accreditation') {
					Details.findOne({"email": request.query.email}, function(err, getProvider) {
						if(err)
							reply(Boom.forbidden(error(err)));
						if(!getProvider)
							reply(Boom.notFound("No such provider registered with us"));
						if(getProvider) {
							var result = {
								school: getProvider.school,
								residency: getProvider.residency,
								fellowship: getProvider.fellowship,
								affilliation: getProvider.affilliation,
								languages: getProvider.languages,
								insurance: getProvider.insurance,
								statement: getProvider.statement
							}
							reply({providerAccreditation:result});
						}
					});
				}				
			}
		}
	});
};

exports.updatedetails = function(server) {
	server.route({
		method: "PUT",
		path: "/v1/updateProvider",
		config: {
			auth: "session",
			validate: {
				query: {
					email: Joi.string().email().required(),
					type: Joi.string().required(),
					locId: Joi.string()
				},
				payload: {
					category: Joi.string(),
					specialty: Joi.string(),
					title: Joi.string(),
					firstName: Joi.string(),
					lastName: Joi.string(),
					zipCode: Joi.string().min(5).max(5),
					gender: Joi.string(),
					dob: Joi.date(),
					webSite: Joi.string(),
					notification: Joi.string().email(),
					cash: Joi.string(),
					offer: Joi.string(),
					cancellationNumber: Joi.string().min(10).max(15),
					school: Joi.string(),
					residency: Joi.string(),
					fellowship: Joi.string(),
					affilliation: Joi.string(),
					languages: Joi.array(),
					insurance: Joi.array(),
					statement: Joi.string(),
					location: Joi.array(),
					plan: Joi.string(),
					billing: Joi.string(),
					price: Joi.string(),
					total: Joi.string(),
				}
			},
			handler: function(request, reply) {
				var userobjid, updateuser, provider; 
				if(request.query.email != request.auth.credentials.profile.email)
					reply(Boom.forbidden("Cannot change other's details"));
				if(request.query.email === request.auth.credentials.profile.email) {
					if(request.query.type === 'location' && request.query.locId === 'new') {
						Details.findOne({"email": request.query.email}, function(err, getProvider) {
							if(err)
								reply(err)
							if(!getProvider)
								reply(Boom.notFound("No such provider"));
							if(getProvider) {
								var location=[], len = 0;
								for(var i=0; i<(getProvider.location).length; i++) {
									len = (getProvider.location).length;
									location.push(getProvider.location[i]);
								}
								var addlocation = {										
									locId: request.query.email+len,
									practiceName: request.payload.location[0].practiceName,
									address: request.payload.location[0].address,
									state: request.payload.location[0].state,
									city: request.payload.location[0].city,
									zip: request.payload.location[0].zip,
									phone1: request.payload.location[0].phone1,
									phone2: request.payload.location[0].phone2,
									fax: request.payload.location[0].fax
								}
								location.push(addlocation);
								Details.update({"email": request.query.email},
									{$set: {"location": location}}, function(err, update) {
										if(err)
											reply(Boom.forbidden(error(err)))
										if(update)
											reply("updated Successfully");
									}
								);
							}
						});
					}	

					else if(request.query.type === 'location' && request.query.locId != undefined) {
						Details.findOne({"email": request.query.email, "location.locId": request.query.locId}, 
							{"location.$":1},
							function(err, location) {
								if(err)
									reply(Boom.forbidden(error(err)))
								if(!location) 
									reply(Boom.notFound("No such location for this provider"));
								if(location) {
									var location = {										
										locId: request.query.locId,
										practiceName: request.payload.location[0].practiceName,
										address: request.payload.location[0].address,
										state: request.payload.location[0].state,
										city: request.payload.location[0].city,
										zip: request.payload.location[0].zip,
										phone1: request.payload.location[0].phone1,
										phone2: request.payload.location[0].phone2,
										fax: request.payload.location[0].fax
									}
									Details.update({"email": request.query.email, "location.locId": request.query.locId},
										{$set: {"location.$": location}}, function(err, update) {
											if(err)
												reply(Boom.forbidden(error(err)))
											if(update)
												reply("updated Successfully");
										}
									);
								}
							}
						);
					}

					if(request.query.type === 'accreditation' && request.query.type != 'location')	{
						if(request.payload.languages === undefined || request.payload.school === undefined) 
							reply(Boom.badRequest('Request with all mandatory details'));
						if(request.payload.languages != undefined && request.payload.school != undefined)  {
							var languages =[], insurance=[];
							for(var i=0; i<(request.payload.languages).length; i++) {
								languages.push(request.payload.languages[i]);
							}
							if(request.payload.insurance != undefined) {
								for(var i=0; i<(request.payload.insurance).length; i++) {
									insurance.push(request.payload.insurance[i].toLowerCase());
								}	
							}	
							var query = {
								"school": request.payload.school,
								"residency": request.payload.residency,
								"fellowship": request.payload.fellowship,
								"affilliation": request.payload.affilliation,
								"statement": request.payload.statement,
								"languages": languages,
								"insurance": insurance
							}			
							if(request.payload.residency === undefined)			
								delete query.residency;
							if(request.payload.fellowship === undefined)			
								delete query.fellowship;
							if(request.payload.affilliation === undefined)			
								delete query.affilliation;
							if(request.payload.statement === undefined)			
								delete query.statement
							if(request.payload.insurance === undefined)			
								delete query.insurance
							Details.update(
								{"email": request.query.email},
								{$set: query},
								function( err, updated) {
									if(err) reply(Boom.forbidden(error(err)));
									if(updated) reply('Updated Successfully').code(200);
								}
							);
						}
					}

					if(request.query.type === 'personal' && request.query.type != 'location') {
						if(request.payload.zipCode === undefined || request.payload.category === undefined || request.payload.specialty === undefined || request.payload.firstName === undefined || request.payload.lastName === undefined || request.payload.title === undefined || request.payload.dob === undefined || request.payload.notification === undefined || request.payload.cancellationNumber === undefined || request.payload.cash === undefined)
							reply(Boom.badRequest('Request with all mandatory details'));						
						if(request.payload.zipCode != undefined && request.payload.category != undefined && request.payload.specialty != undefined && request.payload.firstName != undefined && request.payload.lastName != undefined && request.payload.title != undefined && request.payload.dob != undefined && request.payload.notification != undefined && request.payload.cancellationNumber != undefined && request.payload.cash != undefined) {
							var query = {
								"category": request.payload.category,
								"specialty": request.payload.specialty,
								"title": request.payload.title,
								"firstName": request.payload.firstName,
								"lastName": request.payload.lastName,
								"dob": request.payload.dob,
								"gender": request.payload.gender,
								"zipCode": request.payload.zipCode,
								"webSite": request.payload.webSite,
								"notification": request.payload.notification,
								"cash": request.payload.cash,
								"offer": request.payload.offer,
								"cancellationNumber": request.payload.cancellationNumber							
							}
							if(request.payload.gender === undefined) 
								delete query.gender;
							if(request.payload.webSite === undefined) 
								delete query.webSite;
							if(request.payload.offer === undefined) 
								delete query.offer;
							Details.update({"email": request.query.email}, {$set: query}, function(err, updatedetails) {
								if(err) reply(Boom.forbidden(error(err)));
								if(updatedetails) {
									SignUp.update({"email": request.query.email}, {$set: {"username": request.payload.firstName}}, function(err, updateuser) {
										if(err) reply(Boom.forbidden(error(err)))
										if(updateuser) reply('Updated Successfully').code(OK);
									});
								}
							});

						}
					}					
				}
			}			
		}
	});
};

exports.offer = function(server) {
	server.route({
		method: 'PUT',
		path: '/v1/offer',
		config: {
			auth: 'session',
			validate: {
				query: {
					email: Joi.string().email().required()
				},
				payload: {
					startDate: Joi.string().required(),
					endDate: Joi.string().required(),
					title: Joi.string().required(),
					description: Joi.string().required()
				}				
			},
			handler: function(request, reply) {
				if(request.query.email != request.auth.credentials.profile.email)
					reply(Boom.forbidden("Cannot change other's details"));
				if(request.query.email === request.auth.credentials.profile.email) {
					var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
						startDate = new Date(request.payload.startDate),
						endDate = new Date(request.payload.endDate),
						offerDates=[],
						length = Math.abs(parseInt((startDate.getDate() - endDate.getDate())/(oneDay)));
					
					Details.findOne({"email": request.query.email}, function(err, getProvider) {
						if(err)	reply(Boom.forbidden(error(err)));
						if(!getProvider) reply(Boom.notFound('No such provider registered with us'));
						if(getProvider) {
							for(var index=0; index<length; index++) {
								var formatDate = "";
								var calcdate = new Date();
								calcdate.setDate(startDate.getDate()+index);						
								if (calcdate.getMonth()<9) {
									formatDate += "0" + (calcdate.getMonth()+1);
								} else {
									formatDate += (calcdate.getMonth()+1);
								}
								if (calcdate.getDate()<10) {
									formatDate += "-" +"0" + calcdate.getDate();
								} else {
									formatDate += "-" +calcdate.getDate();
								}
								formatDate += "-" + calcdate.getFullYear();
								offerDates.push(formatDate);
							}
							var query = {
								'specialOffer.dates': offerDates,
								'specialOffer.title': request.payload.title,
								'specialOffer.description': request.payload.description
							}
							Details.update({'email': request.query.email}, {$set: query}, function(err, updated) {
								if(err) reply(Boom.forbidden(error(err)));
								if(updated) reply('Updated Successfully').code(OK);
							});
						}
					});
				}
			}
		}
	});
};

exports.slottedDate = function(server) {
	server.route({
		method:'GET',
		path:'/v1/slottedDate',
		config: {
			validate: {
				query: {
					email: Joi.string().required()
				}
			},
			handler: function(request, reply) {
				Details.findOne({'email': request.query.email}, function(err, getProvider) {
					if(err)	reply(Boom.forbidden(error(err)));
					if(!getProvider)	reply(Boom.notFound('No such provider'));
					if(getProvider) {
						Appointments.find({'prov': request.query.email}, {'date':1, '_id':0}, function(err, dates) {
							var bookedDates=[];
							if(err)	reply(Boom.forbidden(error(err)));
							if(!dates) reply(Boom.notFound('No slots created by this provider'));
							if(dates){
								for(var index=0; index<dates.length; index++) {
									bookedDates.push(dates[index].date);
								}
								reply({slotCreatedDates:bookedDates.sort()});						
							}
						});
					}

				});
				
			}
		}
	});
};