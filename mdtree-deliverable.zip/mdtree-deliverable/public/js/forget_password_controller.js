
mdtreeApp.controller('forget_password_controller', function forget_password_controller($scope,$state,productService,$http,$timeout){

 $scope.questions ={};

$scope.questions.options = [{id:"What was the name of your high school?"},{id:"What is the name of your first PET?"},{id:"What is your all-time favorite sports team?"},{id:"What is your all-time favorite past-time?"},{id:"What was the name of your favorite food as a child?"},{id:"What is your favorite color?"},{id:"What is the name of your hometown?"}];
    
});