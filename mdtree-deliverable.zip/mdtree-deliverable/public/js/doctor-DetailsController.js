mdtreeApp.controller('doctorDetailsController',
    function doctorDetailsController($scope, productService,SelectValueService, $http) { 
    // $scope.$watch(function () { return productService.getdoctorEmailTemp();}, function (data) { 
    //     $scope.specificdoctor = data;

    // });

    
    $scope.bookingdate = [];
    var dayShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var date = new Date();
    console.log(date.getDay());
    var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    console.log(dateStr);
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    $scope.bookingdate.push(dateStr);
    $scope.openTab = function(address,city,state,zip) {
        $scope.url = 'https://www.google.co.in/maps/preview?q='+address+','+city+','+state+','+zip;

    };
    $scope.timeclicked = function(doctor, md_date, md_time,location) {
        var dayFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var date = new Date(md_date);
        var data = {date : md_date, day: dayFull[date.getDay()], time: md_time};
        console.log(doctor);
        console.log(data);
        productService.adddoctordetails(doctor);
        productService.adddate_day_time(data);
        productService.addlocationdetails(location);
    }

    $scope.indexValue = 0;
    $scope.nextslots = function(value){
           // console.log($scope.bookingdate); 
           
           var date = new Date($scope.bookingdate[0].date);
           $scope.bookingdate = [] ;
           if (value == 'prev'){
                date.setDate(date.getDate() - 5);
                $scope.indexValue = $scope.indexValue - 1; 
           }
           else{
                date.setDate(date.getDate() + 5);
                $scope.indexValue = $scope.indexValue + 1; 
           }
            
            var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            $scope.firstsearchoperation($scope.indexValue);
            
        }
    $scope.firstsearchoperation = function(indexValue) {
            
        var temp = "&startindex=0";
        if(indexValue != undefined){
            temp = "&startindex=" + indexValue;
            console.log(temp);
        }
        console.log(temp);
        $scope.Selectedinsurance = [];
        $http.get('v1/provider?email=' + productService.getdoctorEmailTemp() +temp)
            .success(function(data, status, headers, config) {
                $scope.doctordetails = data.provider;
                console.log(data.provider);
                console.log(data.provider.insurance);
                console.log((SelectValueService.getinsuranceJson()));
                for(i = 0 ; i < data.provider.insurance.length ; i++ ){
                    $scope.Selectedinsurance[i] =  (_.findWhere(SelectValueService.getinsuranceJson(), {key:data.provider.insurance[i]})).value ;
                    console.log($scope.Selectedinsurance[i]);
                }
                $scope.SelectedSpeciality = (( _.findWhere($scope.specialty.options, {key:$scope.specialty.doctor} )
                 || _.findWhere($scope.dentistslists.options, {key:$scope.specialty.doctor})
                 || _.findWhere($scope.chiropractors.options, {key:$scope.specialty.doctor}))).value; 


                var tempValue =  _.findWhere(SelectValueService.getcashPriceJson(), {key:data.provider.cash}) ;
                $scope.doctordetails.cash = tempValue.id;
                
                // for(var i=0;i<= data.provider.length;i++){
                    $scope.appointmentHideOrShow="true";
                    for(var j=0;j<data.provider.locations.length;j++){
                        console.log("hi");
                        for(var k=0;k<data.provider.locations[j].appointmentSchedules.length;k++){
                            for(var l=0;l<data.provider.locations[j].appointmentSchedules[k].slots.length;l++){
                                $scope.appointmentHideOrShow="false";
                            }        
                                
                        }
                    }
                // }
            })
            .error(function(data, status, headers, config) {
                console.log(data);
        });
    }
    $scope.firstsearchoperation();

});