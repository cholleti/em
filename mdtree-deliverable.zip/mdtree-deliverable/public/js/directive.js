'use strict';

mdtreeApp.directive('accessLevel', ['Auth', function(Auth) {
    
    return {
        restrict: 'A',
        link: function($scope, element, attrs) {
            var prevDisp = element.css('display')
                , userRole
                , accessLevel;

            $scope.user = Auth.user;
            $scope.$watch('user', function(user) {
                if(user.role)
                    userRole = user.role;
                updateCSS();
            }, true);

            attrs.$observe('accessLevel', function(al) {
                if(al) accessLevel = $scope.$eval(al);
                updateCSS();
            });

            function updateCSS() {
                if(userRole && accessLevel) {
                    if(!Auth.authorize(accessLevel, userRole))
                        element.css('display', 'none');
                    else
                        element.css('display', prevDisp);
                }
            }
        }
    };
}]);


mdtreeApp.directive('activeNav', ['$location', function($location) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var anchor = element[0];
            if(element[0].tagName.toUpperCase() != 'A')
                anchor = element.find('a')[0];
            var path = anchor.href;

            scope.location = $location;
            scope.$watch('location.absUrl()', function(newPath) {
                path = normalizeUrl(path);
                newPath = normalizeUrl(newPath);

                if(path === newPath ||
                    (attrs.activeNav === 'nestedTop' && newPath.indexOf(path) === 0)) {
                    element.addClass('active');
                } else {
                    element.removeClass('active');
                }
            });
        }

    };

    function normalizeUrl(url) {
        if(url[url.length - 1] !== '/')
            url = url + '/';
        return url;
    }

}]);

mdtreeApp.directive('phonenumberDirective', ['$filter', function($filter) {

    function link(scope, element, attributes) {
 
      // scope.inputValue is the value of input element used in template
      scope.inputValue = scope.phonenumberModel;
 
      scope.$watch('inputValue', function(value, oldValue) {
        
        value = String(value);
        var number = value.replace(/[^0-9]+/g, '');
        scope.phonenumberModel = number;
        scope.inputValue = $filter('phonenumber')(number);
      });
    }
    
    return {
      link: link,
      restrict: 'E',
      scope: {
        phonenumberPlaceholder: '=placeholder',
        phonenumberModel: '=model',
      },
      //templateUrl: '/static/phonenumberModule/template.html',
      template: '<input ng-model="inputValue" class="inputtext" type="tel" class="phonenumber" ng-required="true" placeholder="{{phonenumberPlaceholder}}" title="Phonenumber (Format: (999) 9999-9999)">',
    };
  }])
 
  mdtreeApp.filter('phonenumber', function() {
      /* 
      Format phonenumber as: c (xxx) xxx-xxxx
        or as close as possible if phonenumber length is not 10
        if c is not '1' (country code not USA), does not use country code
      */
      
      return function (number) {
        /* 
        @param {Number | String} number - Number that will be formatted as telephone number
        Returns formatted number: (###) ###-####
          if number.length < 4: ###
          else if number.length < 7: (###) ###
 
        Does not handle country codes that are not '1' (USA)
        */
          if (!number) { return ''; }
 
          number = String(number);
 
          // Will return formattedNumber. 
          // If phonenumber isn't longer than an area code, just show number
          var formattedNumber = number;
 
      // if the first character is '1', strip it out and add it back
      var c = (number[0] == '1') ? '1 ' : '';
      number = number[0] == '1' ? number.slice(1) : number;
 
      // # (###) ###-#### as c (area) front-end
      var area = number.substring(0,3);
      var front = number.substring(3, 6);
      var end = number.substring(6, 10);
 
      if (front) {
        formattedNumber = (c + "(" + area + ") " + front);  
      }
      if (end) {
        formattedNumber += ("-" + end);
      }
      return formattedNumber;
      };
  });


mdtreeApp.directive('myDatepicker', function ($parse) {
    return function (scope, element, attrs, controller) {
        var ngModel = $parse(attrs.ngModel);
        $(function(){
            element.datepicker({
                showOn:"both",
                changeYear:true,
                changeMonth:true,
                dateFormat:'mm-dd-yy',
                maxDate: new Date(),

                yearRange: '1940',
                onSelect:function (dateText, inst) {
                    scope.$apply(function(scope){
                        // Change binded variable
                        ngModel.assign(scope, dateText);
                    });
                }
            });
        });
    }
});

mdtreeApp.directive('viewslotsview', function ($parse) {
    return function (scope, element, attrs, controller) {
        var ngModel = $parse(attrs.ngModel);
        $(function(){
            element.datepicker({
                showOn:"both",
                dateFormat:'mm-dd-yy',
                yearRange: '1940',
                onSelect:function (dateText, inst) {
                    scope.$apply(function(scope){
                        // Change binded variable
                        ngModel.assign(scope, dateText);
                    });
                }
            });
        });
    }
});


mdtreeApp.directive('numbersOnly', function(){
   return {
     require: 'ngModel',
     link: function(scope, element, attrs, modelCtrl) {
       modelCtrl.$parsers.push(function (inputValue) {
           // this next if is necessary for when using ng-required on your input. 
           // In such cases, when a letter is typed first, this parser will be called
           // again, and the 2nd time, the value will be undefined
           if (inputValue == undefined) return '' 
           var transformedInput = inputValue.replace(/[^0-9]/g, ''); 
           if (transformedInput!=inputValue) {
              modelCtrl.$setViewValue(transformedInput);
              modelCtrl.$render();
           }         

           return transformedInput;         
       });
     }
   };
});
