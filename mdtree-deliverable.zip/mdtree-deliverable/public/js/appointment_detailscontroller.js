
mdtreeApp.controller('appointment_detailscontroller',function appointment_detailscontroller($scope,$timeout,productService,$state,$http,Auth){
    $scope.$watch(function () { return productService.getdoctordetails()}, function (data) { 
        $scope.doctordetails = data;
        console.log(data);
    });
    $scope.$watch(function () { return productService.getdate_day_time();}, function (data) { 
        $scope.daytimedetails = data;
        console.log(data);
    });
    
        $scope.locationDetails = productService.getlocationdetails();
        console.log("hi");
        if($scope.locationDetails == undefined){
            $scope.locationDetailsInfo = false;
        } else{
            $scope.locationDetailsInfo = true;
        }
        productService.addlocationdetails();
        
    
    $scope.reason = productService.getreason();
    $scope.username = productService.getuserdisplayname();
    // $scope.$watch(function () { return productService.getdoctorEmailTemp();}, function (data) { 
    //     $scope.specificdoctor = data;
    // });
    $scope.userid = Auth.user;
    $scope.zipcode = productService.getlocation();
    $scope.specialty.doctor = productService.getspecialty();
    $scope.insurance = productService.getinsurance();
    $scope.categories = productService.getcategory();
    $scope.emailid = productService.getdoctorEmailTemp();
    $scope.getinsuranceValue = productService.getaddinsurance();
    // http://localhost:8000/v1/provider/search?zip=90002&specialty=cardiology&category=doctors&insurance=aarp&email=thanesh@gmail.com
   
    var queryParams = "v1/provider/search?";
    if ($scope.categories) {
        queryParams += "category="+$scope.categories;
    } else {
        queryParams + "category=doctors";
    }
    if ($scope.specialty.doctor) {
        queryParams += "&specialty="+encodeURIComponent($scope.specialty.doctor);
    }
    if ($scope.zipcode) {
        queryParams += "&zip="+$scope.zipcode;
    }
    if ($scope.emailid) {
        queryParams += "&email="+$scope.emailid;
    }
    
    // if ($scope.insurance) {
    //     queryParams += "&insurance="+encodeURIComponent($scope.insurance);
    // }

    console.log(queryParams);
    
    $scope.reasons = {};
    $scope.reasons.select = "Abdominal pain";
    $scope.reasons.options = [{reason:"Special offer"},{reason:"Abdominal pain"},{reason:"Abnormal bleeding"},{reason:"Allergies"},{reason:"Anxiety"},{reason:"Burning w or urination"},{reason:"Chest pain"},{reason:"Constipation"},{reason:"Coughing"},{reason:"Cracked tooth"},{reason:"Crying"},{reason:"Dental pain"},{reason:"Depression"},{reason:"Diarrhea"},{reason:"Difficulty breath"},{reason:"Discoloration"},{reason:"Dizziness"},{reason:"Dryness"},{reason:"Erectile Dysfunction"},{reason:"Excessive thirst"},{reason:"Fibroids"},{reason:"Frequent bruising"},{reason:"Frequent urination"},{reason:"Genital discharge"},{reason:"Genital odor"},{reason:"Gum pain"},{reason:"Hair loss"},{reason:"Hay Fever"},{reason:"Heart burn"},{reason:"Heat or cold intolerance"},{reason:"Hives"},{reason:"I need braces"},{reason:"Incontinence"},{reason:"Infertility"},{reason:"Joint pain"},{reason:"Loss of hearing"},{reason:"Low libido"},{reason:"Lumps"},{reason:"Mole Changes"},{reason:"Muscle pain"},{reason:"Muscle weakness"},{reason:"Nausea"},{reason:"Nipple discharge"},{reason:"Numbness or tingling"},{reason:"Oily"},{reason:"Painful intercourse"},{reason:"Painful menstruation"},{reason:"Palpitations"},{reason:"Phlegm"},{reason:"Poor circulation"},{reason:"Postcoital bleeding"},{reason:"Rash"},{reason:"Regurgitation"},{reason:"STD"},{reason:"Seizures"},{reason:"Shortness of breath"},{reason:"Sinus problems"},{reason:"Skin changes"},{reason:"Sleep apnea"},{reason:"Sore throat"},{reason:"Swelling"},{reason:"Swollen glands"},{reason:"Teeth cleaning"},{reason:"Teeth whitening"},{reason:"Thoughts of suicide"},{reason:"Tinnitus or Ringing in ears"},{reason:"Urine retention"},{reason:"Vomiting"},{reason:"Wheezing"},{reason:"Wounds"}       
                         ]

    $scope.bookingdate = [];
    var dayShort = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    var date = new Date();
    console.log(date.getDay());
    var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate()};
    
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    date.setDate(date.getDate() + 1);
    dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    $scope.bookingdate.push(dateStr);
    $scope.indexValue = 0;
    $scope.nextslots = function(value){
           // console.log($scope.bookingdate); 
           
           var date = new Date($scope.bookingdate[0].date);
           $scope.bookingdate = [] ;
           if (value == 'prev'){
                date.setDate(date.getDate() - 5);
                $scope.indexValue = $scope.indexValue - 1; 
           }
           else{
                date.setDate(date.getDate() + 5);
                $scope.indexValue = $scope.indexValue + 1; 
           }
            
            var dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
    
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            date.setDate(date.getDate() + 1);
            dateStr = {dayShort: dayShort[date.getDay()], date: (date.getMonth() + 1) + '/' + date.getDate() };
            $scope.bookingdate.push(dateStr);
            $scope.firstsearchoperation($scope.indexValue);
            //localhost:8000/v1/provider/search?zip=90002&specialty=cardiology&category=doctors&insurance=AArp&startindex=1
        }
    $scope.firstsearchoperation = function(indexValue) {
            
        var temp = queryParams;
        if(indexValue != undefined){
            temp = queryParams + "&startindex=" + indexValue;
            console.log(temp);
        }
        console.log(temp);
        $http.get(temp)
            .success(function(data, status, headers, config) {
                console.log(data);
                $scope.singledoctor = data.provider;
                $scope.appointmentHideOrShow="true"
                

                for(var j=0;j<data.provider.appointmentSchedules.length;j++){
                    
                    for(var k=0;k<data.provider.appointmentSchedules[j].slots.length;k++){
                            console.log("appointmentHideOrShow");
                            $scope.appointmentHideOrShow="false";
                    }
                }
                    
            })
            .error(function(data, status, headers, config) {
                console.log(data);
        });
    }
    $scope.firstsearchoperation();
//localhost:8000/v1/provider/search?zip=90002&specialty=cardiology&category=doctors&insurance=AArp&startindex=1&email=dheeraj@gmail.com
     $scope.getUserinfo = function(){
        var url = '/v1/patient?email='+$scope.userid.email+'&view=info';
        $http.get(url).success(function(data){  
            console.log(data);
            $scope.daytimedetails.user = data;

        })
        .error(function(data, status, headers, config) {

        });
     }   

    $scope.bookAppoinmentcomplete = function(){
        // var bookAppoinmentjson = {location:$scope.doctordetails.locationId,provideremail:$scope.doctordetails.email,date:$scope.daytimedetails.date,
        //  patient:{email:$scope.userid.email,name:$scope.userid.username,purpose:$scope.reasons.select,insurance:$scope.insurance,message:$scope.Personalmessage,
        //  },slot:$scope.daytimedetails.time}
        var bookAppoinmentjson;
         console.log(bookAppoinmentjson);
         
                if ($scope.locationDetailsInfo == true ){
                    bookAppoinmentjson = {location:$scope.locationDetails.locationId,provideremail:$scope.doctordetails.email,date:$scope.daytimedetails.date,
             email:$scope.userid.email,name:$scope.userid.username,purpose:$scope.reasons.select,insurance:$scope.insurance,message:$scope.Personalmessage,
            slot:$scope.daytimedetails.time,phoneno:$scope.patient.phone,gender:$scop.patient.gender}
        }else{
            bookAppoinmentjson = {location:$scope.doctordetails.locationId,provideremail:$scope.doctordetails.email,date:$scope.daytimedetails.date,
             email:$scope.userid.email,name:$scope.userid.username,purpose:$scope.reasons.select,insurance:$scope.insurance,message:$scope.Personalmessage,
            slot:$scope.daytimedetails.time,phoneno:$scope.daytimedetails.user.patient.phone,gender:$scope.daytimedetails.user.patient.gender}
        }
           
             console.log(bookAppoinmentjson);
                $http.put('v1/appointment', bookAppoinmentjson).success(function(data){  
                        console.log(data);
                    $state.transitionTo("user.appointment-complete",{
                      },{
                        reload: true,
                        notify: true
                    });

                    }).error(function(data, status, headers, config) {
                      console.log(data);
                        var msg = data.message;
                        var type = "danger";
                        $timeout(function(){
                                $scope.alerts.splice(0, 1);
                         }, 3000);
                        $scope.alerts =[];
                        $scope.alerts.push({msg: msg,type: type});
                }); 

       
    }


    $scope.timeclicked = function(doctor, md_date, md_time) {
            var dayFull = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            var date = new Date(md_date);
            console.log(date.getDay()+1);
            console.log(date.getDay()+1);
            var data = {date : md_date, day: dayFull[date.getDay()], time: md_time};
            productService.adddoctordetails(doctor);
            productService.adddate_day_time(data);
            console.log(data);
    }

    console.log(productService.getdoctorEmailTemp());
    // $scope.singledoctor = productService.getdoctorEmailTemp(); 
    
    $scope.personaldetails = function(){
        var data = {visitreason : $scope.reasons.select , personalmsg :$scope.Personalmessage};
        productService.addreason(data);
        $scope.name = Auth.user.username;

        if($scope.name == '' ){
        $state.transitionTo("anon.appointment-signin",{
              },{
                reload: true,
                notify: true
        });
        }
        else{
        $scope.getUserinfo();
        $state.transitionTo("user.appointment-verify",{
        },{
                reload: true,
                notify: true
        });
        }
    
}
});

