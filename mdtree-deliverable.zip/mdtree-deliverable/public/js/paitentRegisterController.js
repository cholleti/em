
mdtreeApp.controller('patientreg', function patientreg($scope,$state,productService,$http,$timeout,Auth){
    $scope.questions= {};

    $scope.boolChangeClass = false;
    $scope.questions.select = "What was the name of your high school?";
    $scope.questions.options = [{id:"What was the name of your high school?"},{id:"What is the name of your first PET?"},{id:"What is your all-time favorite sports team?"},{id:"What is your all-time favorite past-time?"},{id:"What was the name of your favorite food as a child?"},{id:"What is your favorite color?"},{id:"What is the name of your hometown?"}];
 
    $scope.submitform = function(){
        var gender;
        if($scope.boolChangeClass ==false){
            gender = "male";
        }else{ gender = "female" };
        console.log(gender);
        var userdetails ={firstName:$scope.firstName,lastName:$scope.lastName,zipCode:$scope.zipCode,gender:gender,dob:$scope.dob,email:$scope.email,phone:$scope.phone,password:$scope.password,question:$scope.questions.select,answer:$scope.answer};
        console.log(userdetails);
        Auth.register(userdetails,
            function(res) {
              productService.addusertypevalue(res.user);
             $state.transitionTo("user.patient-registration2",{
              },{
                reload: true,
                notify: true
            });
                
            },
            function(err) {
                var msg = err.message;
                var type = "danger";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
            });
        };
        
    $scope.displayTermMessage = function(){
      $scope.DisplayTermMessageError ="You must read and accept the Terms & Conditions before submitting the details. "
    }
    $scope.selected = true;
    
      // // $scope.today = function() {
      // //   $scope.dob = new Date();
      // // };
      // $scope.today();

      $scope.clear = function () {
        $scope.dob = null;
      };

      // Disable weekend selection
      $scope.disabled = function(date, mode) {
        return ( mode === 'day' && ( date.getDay() === 0 || date.getDay() === 6 ) );
      };

      $scope.toggleMin = function() {
        $scope.minDate = $scope.minDate ? null : new Date();
      };
      $scope.toggleMin();

      $scope.open = function($event) {
        $event.preventDefault();
        $event.stopPropagation();
        $scope.opened = true;
      };


      $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
      };

      $scope.initDate = new Date('2016-15-20');
      $scope.formats = ['MM-dd-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
      $scope.format = $scope.formats[0];


});

