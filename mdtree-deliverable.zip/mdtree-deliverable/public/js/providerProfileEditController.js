mdtreeApp.controller('providerProfileEditController', function providerProfileEditController(Auth,$scope,$state,productService,SelectValueService,$http,$timeout,$upload,fileReader,$location){
	$scope.user = Auth.user;
    $scope.categories = {};
     $scope.categories.options = SelectValueService.getCategoryJson();
    $scope.specialty= {};
    $scope.title= {};

    $scope.title.options = SelectValueService.gettitleJson();

    $scope.state ={};
    $scope.state.options = SelectValueService.getStateJson();
    $scope.languages ={};
    $scope.specialty= {};
    $scope.specialty.options = SelectValueService.getDoctorsJson();
    $scope.dentistslists= {};
    $scope.dentistslists.options = SelectValueService.getdentistslists();
    $scope.chiropractors= {};
    $scope.chiropractors.options = SelectValueService.getchiropractors();
    $scope.languages.options = SelectValueService.getLangJson();
    $scope.plan ={};

    $scope.plan.options = SelectValueService.getplanType();
    $scope.insurance ={};

    $scope.BillingInterval ={};

    // $scope.BillingInterval.options = [{id:"Monthly ($200 / mo )"},{id:"Quarterly ($180 / mo )"},{id:"Biannually ($150 / mo )"},{id:"Annually ($100 / mo )"}];
    // $scope.payment ={};
    // $scope.payment.options = [{id:"ACH"},{id:"BCH"},{id:"HDFC"},{id:"ICICI"}];
    // $scope.ExistingAddress ={};
    // $scope.ExistingAddress.options = [{id:"Location 1"},{id:"Location 2"},{id:"Location 3"},{id:"Location 4"}];
    $scope.cashprice ={};

    $scope.cashprice.options = SelectValueService.getcashPriceJson();
    $scope.insurance.options = SelectValueService.getinsuranceJson();
    $http.get('/v1/provider?email='+$scope.user.email + '&type=personal').success(function(data){  
            console.log(data.providerDetails);
            $scope.providerDetails = data.providerDetails;
            if($scope.providerDetails.gender == 'female'){
                $scope.boolChangeClass = true;
            }
        }).error(function(data, status, headers, config) {
          console.log(data);

    }); 
    $scope.locData = [];
    $scope.locationsValues = [];
    $scope.getLoctaionDetails = function(){
    	$http.get('v1/provider?email=' +$scope.user.email+'&type=alllocation')
	        .success(function(data, status, headers, config) {
                console.log(data); 
                console.log(data.providerLocations);
	            $scope.locationsValues.options = data.providerLocations;
	            $scope.locationsValues.locations = data.providerLocations[0].locId;
	           	console.log(data); 
	           	$scope.getSpecificLocation(data.providerLocations[0].locId);
	        })
	        .error(function(data, status, headers, config) {
	            console.log(data);
	    });
    }
    $scope.changePasswordHide = true;
    $scope.changePhotoHide = true;
    $scope.changepassword = function(){
        $scope.changePasswordHide = !$scope.changePasswordHide;
    }
    $scope.changePhoto = function(){
        $scope.changePhotoHide = !$scope.changePhotoHide;
    }
    $scope.getSpecificLocation  = function(locid){
    	console.log(locid)
        var url = '/v1/provider?email='+$scope.user.email+'&type=location&locId='+locid;
        console.log(url);
    	$http.get(url)
	        .success(function(data, status, headers, config) {
	            console.log(data);
                $scope.providerLocation = data.providerLocation;

                console.log(data.providerLocation.address);
	        })
	        .error(function(data, status, headers, config) {
	            console.log(data);
	    });
    }
    $scope.accreditationDetails = function(){
        $http.get('/v1/provider?email='+$scope.user.email+'&type=accreditation')
            .success(function(data, status, headers, config) {
                console.log(data);
                $scope.providerAccreditation = data.providerAccreditation;

            })
            .error(function(data, status, headers, config) {
                console.log(data);
        });
    }
    $scope.updateProfile = function(){
        $scope.gender = [];
        if($scope.boolChangeClass = false){
                $scope.gender.value= "female"
            }else{
                $scope.gender.value= "male"
        }
        // var formatDate = "";
        // console.log($scope.providerDetails.dob);
        // if ($scope.providerDetails.dob.getMonth()<9) {
        //     formatDate += "0" + ($scope.providerDetails.dob.getMonth()+1);
        //   } else {
        //     formatDate += ($scope.providerDetails.dob.getMonth()+1);
        //   } 
        //   if ($scope.providerDetails.dob.getDate() < 10) {
        //     formatDate += "-" + "0" + $scope.providerDetails.dob.getDate();
        //   } else {
        //     formatDate += ("-" + $scope.providerDetails.dob.getDate());
        //   }
          
        //   formatDate += "-" + $scope.providerDetails.dob.getFullYear();

        //   console.log(formatDate);

            var urlJson = 
            {"specialty":$scope.providerDetails.specialty,"category":$scope.providerDetails.category,"title":$scope.providerDetails.title,
            "firstName":$scope.providerDetails.firstName,
            "lastName":$scope.providerDetails.lastName,"dob":$scope.providerDetails.dob,"gender":$scope.gender.value,
            "zipCode":$scope.providerDetails.zipCode,
            "notification":$scope.providerDetails.notification,
            "cash":$scope.providerDetails.cash,"offer":$scope.providerDetails.offer,
            "cancellationNumber":$scope.providerDetails.cancellationNumber,"webSite":$scope.providerDetails.webSite};
            console.log("msg json is",urlJson);
        $http.put('/v1/updateProvider?email='+$scope.user.email+'&type=personal',urlJson)
            .success(function(data, status, headers, config) {
                console.log(data);
                var msg = data;
                var type = "success";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});

            })
            .error(function(data, status, headers, config) {
                console.log(data);
                var msg = data.message;
                var type = "danger";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
        });
    }
    $scope.updateLoctaion = function(){
        
        var urlJson = {"location":[{"address":$scope.providerLocation.address,"practiceName":$scope.providerLocation.practiceName,"state":$scope.providerLocation.state,"city":$scope.providerLocation.city,"zip":$scope.providerLocation.zip,"phone1":$scope.providerLocation.phone1}]}
        console.log(urlJson);
        
        $http.put('/v1/updateProvider?email='+$scope.user.email+'&type=location&locId='+$scope.locationsValues.locations,urlJson)
            .success(function(data, status, headers, config) {
                console.log(data);
                var msg = data;
                var type = "success";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});

            })
            .error(function(data, status, headers, config) {
                console.log(data);
                var msg = data.message;
                var type = "danger";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
        });
    }
    $scope.updateaccreditation = function(){
        var urlJson =  {"school":$scope.providerAccreditation.school,"languages":$scope.providerAccreditation.languages,"insurance":$scope.providerAccreditation.insurance,
        }
        if($scope.providerAccreditation.statement){
            urlJson.statement = $scope.providerAccreditation.statement;
        }
        if($scope.providerAccreditation.fellowship){
            urlJson.statement = $scope.providerAccreditation.fellowship;
        }
        if($scope.providerAccreditation.residency){
            urlJson.statement = $scope.providerAccreditation.residency;
        }

        console.log(urlJson);
       $http.put('/v1/updateProvider?email='+$scope.user.email+'&type=accreditation',urlJson)
            .success(function(data, status, headers, config) {
                console.log(data);
                var msg = data;
                var type = "success";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});

            })
            .error(function(data, status, headers, config) {
                console.log(data);
                var msg = data.message;
                var type = "danger";
                // $timeout(function(){
                //         $scope.alerts.splice(0, 1);
                //  }, 3000);
                $scope.alerts =[];
                $scope.alerts.push({msg: msg,type: type});
        });
    }

});