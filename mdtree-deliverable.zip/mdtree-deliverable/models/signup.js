var Mongoose = require("mongoose"),
	Schema = Mongoose.Schema;
	
//schema for signup user to refer during login
var signup = new Schema ({
	email: {type: String, trim: true, required: true},
	password: {type: String, trim: true, required: true},
	temppassword: {type: String, trim: true},
	title: {type: String, trim: true, required: true},
	bitMask: {type: String, trim: true, required:true},
	question: {type: String, trim: true},
	answer: {type: String, trim: true},
	username: {type: String, trim: true, required: true},
	attempt: {type: String, trim: true}
});

var signup = Mongoose.model("signup", signup);

module.exports = {
	SignUp: signup
};