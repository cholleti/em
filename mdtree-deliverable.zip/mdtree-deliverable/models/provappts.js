var Mongoose = require("mongoose"),
	Schema = Mongoose.Schema;
	
//schema for provider appointments details
var provappts = new Schema ({
	date: {type: String, required: true, trim: true},
	slots: {type: Array, required: true, trim: true},
	prov: {type: String, required: true, trim: true},
	loc: {type: String, required: true, trim: true}
});

var provappts = Mongoose.model("provappts", provappts, "providers");

module.exports = {
	Appointments: provappts
};